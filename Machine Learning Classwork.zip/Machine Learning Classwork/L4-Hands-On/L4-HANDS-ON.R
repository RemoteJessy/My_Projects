# P A R T 1 - BACKWARD  ELIMINATION - IQ Dataset

# 1. LOAD IN DATA
IQ <- read.csv("C:/Users/lzela/Downloads/IQ.csv")
View(IQ)

#Question: 1. Which model is the best? Why? 2. From the best model, what is the adjusted R2 value and what does it mean? 3. From the best model, how does each variable influence IQ?

# 2. Get a Baseline:
FitAll = lm(IQ ~ ., data = IQ)

# 3. model summary
summary(FitAll)
# F-statistic is 1.195. Multiple R-squared is 0.3991. 
#Adjusted R2 is 0.06, which means it's not significant.
#None of the values are less than 0.05, so not significant.
#Therefore, it might make a difference adding one. 
#P-value is not significant (0.06).

# 4. Try Backward Elimination
step(FitAll, direction = 'backward')
#The LAST MODEL is definitely the best at an AIC of 71.69.
# These seem to be the ones that makes an impact and a difference are IQ ~ Test1 + Test2 + Test4.

# 5. Make the model with the variables it thinks is good to verify.
fitsome = lm(IQ ~ Test1 + Test2 + Test4, data = IQ)
summary(fitsome)
#CONCLUSION: 
# p-value is 0.1 Not significant.
#Multiple R-squared is .38 (38% that makes a difference). So 72% DON'T make a difference.
#Adjusted R-squared is .21, which is 21%. Even worse. 21% makes a difference.
#In reality pretty much nothing makes a difference here.
#Only test 4 is a significant, but the rest is not.
#This was unsuccessful.

















# P A R T 2 Compare Regression Types - stepwiseRegression Dataset

#LOAD DATA
stepwiseRegression <- read.csv("C:/Users/lzela/Downloads/stepwiseRegression.csv")
View(stepwiseRegression)

# 1. Backward Selection
FitAll = lm(Y ~ ., data = stepwiseRegression)
summary(FitAll)
#The p-value is significant, being <0.05.
#The multiple R-squared is pretty high at 99%, making it significant.
#Adjusted R-squared is the same.

step(FitAll, direction = 'backward', scope = formula(FitAll))
#The last step is AIC at 213.38, which is the lowest. 
# It kept X variables 2, 4, 6, 10, 11, and 12.


#. 2. Forward Selection
fitstart = lm(Y ~ 1, data = stepwiseRegression)
summary(fitstart)

step(fitstart, direction = 'forward', scope = (formula(FitAll)))
#The last step, model, is the best with an AIC of 213.38.
#It kept the x variables 6, 4, 12, 10, 2, and 11.


# 3. StepWise H Y B R I D
step(fitstart, direction = 'both', scope = formula(FitAll))
# The last model has the lowest AIC at 213. 38.
#It kept the x variables 6, 4, 12, 10, 2, and 11. Going to apply it below.

#Naming it fitsome because we're only keeping these x variables below.
fitsome <- lm(formula = Y ~ X2 + X4 + X6 + X10 + X11 + X12, data = stepwiseRegression)
summary(fitsome)
# It is very much significant at < 2.2e-16, which is <0.05.
# The R-squared is at 99%, which makes a huge difference.
#This model is almost the same as backward selection. 


##### Conclusion: 
##### Backward's adjusted R-square came in at one point higher, which means it's a better fit. 
##### It was closest to 100% and it was significant at 0.05.