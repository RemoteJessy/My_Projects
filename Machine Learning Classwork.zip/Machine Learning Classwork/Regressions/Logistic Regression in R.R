#Logistic Regression in R

#Load in Libraries
library("caret")
library("magrittr")
library("dplyr")
library("tidyr")
library("lmtest")
library("popbio")
library("e1071")
library("lattice")
library("ggplot2")
library("zoo")


#caret and lmtest will be used to test assumptions, dplyr, tidyr, and magrittr are used for data wrangling, and popbio is used to graph your logistic regression model.


# Load in Data
baseball <- read.csv("C:/Users/lzela/Downloads/baseball.csv")
View(baseball)

#Question Setup: Even though runs can be scored a number of different ways, you can investigate how good a predictor home runs are to determine the winner. It seems logical to assume that the more home runs a team hits in a particular game, the more likely they are to win. So you will do a regression where the predictor (IV) is the number of home runs hit by a team, and the response variable (DV) is whether the team wins or loses. This is a case of a quantitative predictor variable, and a categorical response variable.

#Data Wrangling: The one thing that absolutely has to be done before you can dive into logistic regression is the recoding of the outcome variable (DV) to zeros and ones. Currently, your wins and losses variable (W.L) has a W indicating a win and an L indicating a loss. In R, that just won't fly - you need this outcome variable to be numeric. The following code will create a new wins and losses column that will re-code this variable numerically:
baseball$WinsR <- NA
baseball$WinsR[baseball$W.L=='W'] <- 1
baseball$WinsR[baseball$W.L=='L'] <- 0

##### Testing Assumptions #####

#1. Appropriate Sample Size
#The first thing you need to do to test for appropriate sample size is to create the logistic regression model.

#2. Run the Base Logistic Model: create a model first before you can ensure that it meets all the assumptions.
#glm is for logistic regession
mylogit <- glm(WinsR ~ HR.Count, data=baseball, family="binomial")
#This code should look somewhat familiar to you, as it stems from the same one as your linear regression. However, instead of just lm() you now use glm() and you need to specify family= . Here you have chose binomial because you are doing Binomial Logistic Regression. Place your dependent variable first, the new WinsR column that you re-coded, and then you will add your independent variable after the tilde. baseball is the name of your dataset.

#3. Predict Wins and Losses
#With that model created (but not interpreted!), you can make predictions about wins and losses. To do this, you will use the predict() function on your logit model first:
probabilities <- predict(mylogit, type = "response")
#Then convert your probabilities to a positive and negative prediction by having anything above .5 (half) be positive, and anything below .5 be negative. This will be done using the ifelse() function on the probabilities variable you just created, and it will be assigned to your baseball data set, as the column Predicted, so that you can later compare it with the recoded wins and losses column.
probabilities <- predict(mylogit, type = "response")
baseball$Predicted <- ifelse(probabilities > .5, "pos", "neg")


#4. Recode the Predicted Variable
#Just like you recoded wins and losses, you also need to recode your new Predicted variable:
baseball$PredictedR <- NA
baseball$PredictedR[baseball$Predicted=='pos'] <- 1
baseball$PredictedR[baseball$Predicted=='neg'] <- 0

#5. Convert Variables to Factors
baseball$PredictedR <- as.factor(baseball$PredictedR)
baseball$WinsR <- as.factor(baseball$WinsR)

#6. Create a Confusion Matrix
# And now you are finally ready to create a 2x2 chart, also known as a confusion matrix, which will not only test your sample size out, but will also provide some information on the accuracy of our prediction. Using the caret library, you will call the confusionMatrix() function, specifying that you want to compare your predicted values (PredictedR) to your actual data, which is the WinsR column.
conf_mat <- caret::confusionMatrix(baseball$PredictedR, baseball$WinsR)
conf_mat
###### NOTE: The first thing you will notice is the table at the top. This is your 2x2 chart, and it shows the following:
#Top left corner (Reference: 0, Prediction: 0): These are the cases that failed the condition and were predicted to fail the condition. In your case, a loss was predicted and a loss actually happened.
#This is the number you accurately predicted as "did not happen."
#Top right corner (Reference: 1, Prediction: 0): These are the cases that were predicted to fail the condition, but did not actually fail. In terms of the current dataset: a loss was predicted, but the team actually won.
#Bottom left corner (Reference: 0, Prediction: 1): These are the cases where a success was predicted, but a failure actually happened. This means that the team was predicted to win, but they actually lost.
#Bottom right corner (Reference: 1, Prediction: 1): These are the cases were a success was predicted and a success actually happened. So, the team was predicted to win and they actually won.
#This is the number you accurately predicted as "did happen."
#If any one of these four cells in the chart is below 5, then you do not meet the minimum sample size for binary logistic regression. Luckily, you have a large dataset, and so you pass this assumption!
#There is also some other useful information contained within the confusion matrix output, however. The accuracy rate shows how accurate your predictions are. With a .639 accuracy rate, this means that roughly 64% of the time, your predictions are correct. If you added additional independent variables to your model, then perhaps this accuracy rate would go up. The confusion matrix also has information on sensitivity, specificity, the positive predicted value, and the negative predicted value. Although those are not statistics you will focus on now, they will come up again later when you discuss receiver operator curve analyses, so it's worth getting a heads up on where they can be located in R.

#7. Logit Linearity
#Now you have your model and your predictions, you can calculate the logit and then graph it against your predicted values.
#You will need to do a little more data wrangling to properly create your logit. You only want to assess the linearity of the logit with numeric variables, so using the library dplyr, and the select_if() function, you can select only numeric columns from the full dataset by specifying as the argument is.numeric.
baseball1 <- baseball %>% 
dplyr::select_if(is.numeric)

#8. Then you will pull the rename the column names to be fed into predictors using the colnames() function:
predictors <- colnames(baseball1)

#9. And finally you can create the logit, using tidyr's mutate() and gather() functions. The logit is calculated as the log of the probabilities divided by one minus the probabilities.
baseball1 <- baseball1 %>%
mutate(logit=log(probabilities/(1-probabilities))) %>%
gather(key= "predictors", value="predictor.value", -logit)

#10. Graph to assess for linearity using ggplot2
ggplot(baseball1, aes(logit, predictor.value))+
geom_point(size=.5, alpha=.5)+
geom_smooth(method= "loess")+
theme_bw()+
facet_wrap(~predictors, scales="free_y")
#This will automatically give you a graph of the logit with every numeric variable. Of course, in this case, all you care about is the number of home runs, denoted by the upper right hand corner graph labeled HR.Count. Lucky for you, this shows a nice strong linear relationship, so you are good to move on to testing the next assumption!

#11. Multicollinearity
#The next assumption you would normally test for is multicollinearity; you can't have your independent variables too closely related to each other. However, since you only have one independent variable, you can skip this step.

#12. Independent Errors
#You can test for independent error by graphing the residual over your index.

#13. Graphing the Errors
#You can test this a number of ways. The first way is to graph the errors, and there's a nice, easy line of code for this:
plot(mylogit$residuals)
#Where mylogit is the model you created, and residuals is an automatic output of that model that you can call.
#You are looking for a pretty even distribution of points all the way across your x axis. You have that, so you have met the assumption of independent errors.

#14. (Alternative to step above) Use The Durbin-Watson Test
#Alternatively, you can use the Durbin-Watson test to see whether you have independence of errors. You'll use the function dwtest() out of the lmtest library:
dwtest(mylogit, alternative="two.sided")
#Using the alternative="two.sided" argument means that you are testing for both positive and negative autocorrelation of errors.
#If this test is not statistically significant (> .05), then you are automatically good to go, and you have independent errors. However, if it is significant, you can then look at the actual value of the Durbin-Watson test statistic. If it is under 1 or greater than 3, then you have violated the assumption of independent errors. Since your DW value is 2.08, you are in an ok range and have met the assumption of independent errors through testing as well as graphing!

#15. Screening for Outliers
infl <- influence.measures(mylogit)
summary(infl)
#Notice that this is not even all the output! You may want to consider creating your own function that will print only the rows that are suspicious. Remember that if dfb.1_ or dffit values are greater than 1, or if hat is greater than .3 or so, you probably have an outlier than should be examined and possibly removed.

#NOTE: You need to create the logit using dplyr. To test for independent errors: Graph and/or influence.measures()

#Running Logistic Regression and Interpreting the Output
#16. Call your logistic regression model and interpreting the output by asking for the summary:
summary(mylogit)
#NOTE: In this output, the first thing to check is whether your independent variable, the number of home runs, was a significant predictor of the number of wins and losses a team had. Looking in the Coefficients table under HR.Count, you see that the p value is significant at p < .001, which is great news. This means that the number of home runs is a significant predictor of the number of wins and losses a team had. The z value given next to p is the Wald Statistic, and you can think of it similarly to the t tests you had for individual predictors in linear regression - it's just that Wald works for categorical variables and t tests don't. In the same line, the estimate tells you how much the independent variable influences the dependent. So, for every one unit increase in home runs, you see that the log odds of winning a game (versus losing) are increased by .66. You also have a number of other components here that tell you about model fit, including the deviance residuals, null and residual deviance, and the AIC.

#17. Graphing the Logistic Model
#Want to plot it? You can use the popbio library to do so with this code:
logi.hist.plot(baseball$HR.Count,baseball$WinsR, boxp=FALSE, type="hist", col="gray")