#Quadratic Modeling in R

#Load libraries
library("ggplot2")

#Load Data
fish <- read.csv("C:/Users/lzela/Downloads/fish.csv")
View(fish)

#Question Setup
#The question you will be answering is: Does the age of the bluegill fish influence their length?

#Graph a Quadratic Relationship
quadPlot <- ggplot(bluegill_fish, aes(x = age, y=length)) + geom_point() + stat_smooth(method = "lm", formula = y ~x + I(x^2), size =1)
quadPlot
#Looks like a quadratic line is a pretty good fit for the data!

#Model the Quadratic Relationship (first the x which is the age)
Agesq <- bluegill_fish$age^2
# Now we model the Y which is the length
quadModel <- lm(bluegill_fish$length~bluegill_fish$age+Agesq)
summary(quadModel)

#Result from the summary: Looking at the overall F-statistic shown on the bottom and associated p-value, this quadratic model is significant! This means that age is a significant quadratic predictor of bluegill fish length.
