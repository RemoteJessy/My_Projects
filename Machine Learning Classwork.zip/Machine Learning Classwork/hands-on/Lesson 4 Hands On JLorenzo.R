trials <- 10000

alpha <- 9
beta <- 1

Bleach <- rbeta(trials, 27+alpha, 41 + beta)
BleachNScrub <- rbeta(trials, 10+alpha, 18 + beta)

WhatsItGonnaBe <- sum(BleachNScrub > Bleach) / trials
# The result is 65%. 
#Bleach and scrubbing wins, with less chances of mold not returning.