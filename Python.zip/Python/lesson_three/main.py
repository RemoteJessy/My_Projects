#  LIST
list is a data structure that holds a collection of objects. 
In other programming languages, this data structure is sometimes called an array.

my_message = "Split these words for me"
split_at_spaces = my_message.split()
The result of calling split on the above string variable resulted in the creation of a list.

['Split', 'these', 'words', 'for', 'me']
As you can see above, all of the words are between square brackets ([ and ]) and are separated with commas. 
This is the structure of a list in Python.

a single list object could contain, 
for example, a float, integer, and a string (or other data types).

# example of a list:
another_variable = "Hello world"
my_list = ["String", 3, 7.5, another_variable]

print(my_list)

['String', 3, 7.5, 'Hello world']

disney_princess = ['The Little Mermaid', 'Snow White', 'Sleeping Beauty', 'Rapunzel', 'Ana & Elsa', 'Raya', 'Cinderella', 'Mulan', 'Moana', 'Brave', 'Sofia The First']
print(disney_princess)
____________________________________________________________________
# NESTED LIST
A list that contains other lists - nested list.
# example:
INPUT:
our_world = ['Earth', ['United States', 'Canada', 'Mexico'], [1, 2, 3]]
print(our_world)
OUTPUT:
['Earth', ['United States', 'Canada', 'Mexico'], [1, 2, 3]]
____________________________________________________________________
# Empty Lists
There will be times when you need to start with an empty list.

my_empty_list = []
____________________________________________________________________
# Tuples
Before you jump into additional list work, another data type will be covered: tuples. Lists work well for storing collections that have the ability to change throughout the life of your program. However, sometimes you may find that you need to create a collection of items that cannot change. This is where a tuple could be used. A tuple is a sequence, just like a list, except a tuple is immutable, or unchangeable. This means that the values inside of a tuple cannot be modified.

When you use tuples in your code, you are saying to others that you do not intend for there to be any changes to the values. When it comes to performance, since the values do not change, you can optimize your code with the use of tuples in Python.

The structure of a tuple is nearly identical to that of a list, except that instead of square brackets [] surrounding the list of items, parentheses () are used. This is best illustrated with examples:

my_tuple = ('doctor', 'nurse', 'PA')
print(my_tuple)
OUTPUT:

('doctor', 'nurse', 'PA')
____________________________________________________________________
# Empty Tuples
You can create empty tuples:

empty_tuple = ()
____________________________________________________________________
# Tuple with One Element
When you create a tuple that contains only one element, you must still add a comma after it. It will look weird, but it's necessary. This is because the interpreter will not know if you meant a value simply inside of parentheses (like when performing arithmetic operations), or if you meant a tuple.

one_item_tuple = ('just me',)
print(one_item_tuple)
OUTPUT:

('just me', )
Mixed Data Type Tuples
Like lists, tuples can store any data type, and they can be mixed:

# you've already seen a string tuple
string_tuple = ("this", "contains", "string", "values")

# you can, of course, create tuples with numbers
number_tuple = (23, 23.5, 9, 144)

# like lists, you can create tuples with a mix of types
mixed_tuple = ("Bob", 33, "Sally", 29, "Spike", 8)
____________________________________________________________________
# Lists and Tuples Indexing
At some point, you'll need to know how many items are in a collection. The procedure to get the count is the same for both lists and tuples. In Python, the number of items in a collection is referred to as it's length.

You're already familiar with the print() function, which takes a parameter that is printed to the console. The len() function is used to get a count of the items in a collection. Like the print() function, len() requires a parameter: the list or tuple to be counted.

colors_list = ['red', 'green', 'blue', 'yellow']
num_colors = len(colors_list)
print(num_colors)
OUTPUT:

4
That's it! As you can see above, the length of colors_list is 4 — there are four values in the list.
____________________________________________________________________
# Indexing

You've learned how to structure lists and tuples, but how do you interact with them? How can you add, remove, change or even read the information in a list without printing the entire list? This is where the use of the index, or position, of an item in a list is important. Python considers the first item in a list to be at position 0 and not position 1 (unlike R). These positions are integers. This is illustrated below:

[red, yellow, blue, green, purple]

  0      1      2     3      4
Above you can see that red is the first value in the list. So, its index is 0. The second value, yellow, is at index 1. The third value is at index 2. And so on.

To access values in a list or tuple, you append the index enclosed within square brackets [] to the end of the variable. The examples below illustrate how to access individual items in a list and tuple:

# print the third item of the list
colors_list = ['red', 'green', 'blue', 'yellow']
print(colors_list[2])

# print the second item of the tuple
numbers_tuple = (22, 33, 44, 55)
print(numbers_tuple[1])
OUTPUT:

blue
33
____________________________________________________________________
# Accessing the Last Item in a List or Tuple
If you know the index of the last item, you can access it like you saw earlier. However, there is also a special index that can be used to access the last element, which is handy when you don't know how many items are in the collection.

To access the last item in a list, you can specify -1 as the index:

# print the last item of the list
colors_list = ['red', 'green', 'blue', 'yellow']
print(colors_list[-1])

# print the last item of the tuple
numbers_tuple = (22, 33, 44, 55)
print(numbers_tuple[-1])
OUTPUT:

yellow
55
____________________________________________________________________
# To access the next to the last item, you can use -2 as the index. You can use -3 as the index to access the second from the last item. Basically, you can access the elements of a collection in reverse order, where the first item (the last in the list) starts with -1, and continues by reducing the index value by 1. Take a look:

colors_list = ['red', 'green', 'blue', 'yellow']

# access the last item with index `-1`
first_from_end = colors_list[-1]

# access the next-to-last item with index `-2`
second_from_end = colors_list[-2]

# access the second from the last item with index `-3`
third_from_end = colors_list[-3]

print(first_from_end)
print(second_from_end)
print(third_from_end)
OUTPUT:

yellow
blue
green
____________________________________________________________________
# Accessing Multiple Items Within a Range
You can also access a range of items within a collection. This is done by specifying the starting index, followed by a colon :, then specifying the ending index. While the item at the starting index will be returned, the item at the ending index will not. The ending index that is specified is non-inclusive, meaning that it specifies where to stop, but does not give you the value itself.

[0:3] - returns items at positions 0, 1, and 2
[1:4] - returns items at positions 1, 2, and 3
Below are two examples:

colors_list = ['red', 'green', 'blue', 'yellow']

# get the first three items
first_three_items = colors_list[0:3]

# get the middle two items
middle_two_items = colors_list[1:3]

print(first_three_items)
print(middle_two_items)
OUTPUT:

['red', 'green', 'blue']
['green', 'blue']
In the above code, the variables first_three_items and middle_two_items are lists. Do you know why? You're accessing multiple items of the list at one time, so it's returning those items as a list.
____________________________________________________________________
# Modifying an Item in a List
In order to make a change to an item in a list, it's as simple as assigning the specific item to a new value. You just learned how to access a specific element in a list, so now you get to combine steps together!

Here's an example:

# the starting list
contacts = ['Sally', 'Bob', 'Mary', 'Steven']

# Bob prefers to go by "Robert"
# Bob is at index 1 in the list
contacts[1] = "Robert"

print(contacts)
OUTPUT:

['Sally', 'Robert', 'Mary', 'Steven']
The above code creates an initial list of people in a contact list: contacts. It then changes Bob to Robert by assigning the new value to the item at index 1:

contacts[1] = "Robert"
Another Example
Below are a few more examples, and take special note of the last one:

colors_list = ['white', 'white', 'white', 'white']
print(colors_list)

colors_list[0] = 'red'
colors_list[1] = 'green'
colors_list[2] = 'blue'
colors_list[3] = 'yellow'
print(colors_list)

colors_list[-1] = 'purple'
print(colors_list)
OUTPUT:

['white', 'white', 'white', 'white']
['red', 'green', 'blue', 'yellow']
['red', 'green', 'blue', 'purple']
In the above code, the colors_list starts off with four white colors. Each item is then set to new values. Finally, the last item is set to purple. Did you notice the -1 for the index? Remember the negative sign means that you are starting from the end and working your way forward!
____________________________________________________________________
# Adding an Item to the End of the List
Let's say you want to add a new element to a list. For example, you might want to add new users to a website you've built. In order to add an item to a list, you use the append operation. You can only append one item at a time.

Just like the split operation that you used on a string variable, append is used in the same fashion: adding a period . after the variable, then the append command. Using append requires that you provide it a single parameter: the item you wish to add.

my_string = "Hello there Bob"

# splits string into list using space as the delimiter/separator
my_string_items = my_string.split()
print(my_string_items)

# but we forgot Sally!
# add 'and' and 'Sally' to the list
my_string_items.append("and")
my_string_items.append("Sally")

print(my_string_items)
OUTPUT:

['Hello', 'there', 'Bob']
['Hello', 'there', 'Bob', 'and', 'Sally']
In the above code, the following lines add a new item to the list ('and' and 'Sally'):

my_string_items.append("and")
my_string_items.append("Sally")
Simple!

Here are a few more examples:

numbers = [1, 2, 3, 4, 5]

# add 6 to the end
numbers.append(6)

# add 'seven' to the end
numbers.append('seven')
print(numbers)
OUTPUT:

[1, 2, 3, 4, 5, 6, 'seven']
As you can see above, you can mix types: 'seven', a string, was added to the list which, at the time, consisted only of numbers.

Try It!
Append three new elements to the end of a list and print your list to the terminal. Did you get all of the elements expected?

Inserting an Item Into the List
When you use append, it places the element at the end of the list. However, there will be times when you'll want to add an item to a list, but at a specific position. This is called insertion, and the insert command is used. You can insert only one item at a time.

Like the append command, insert requires the item to be added as a parameter. However, it also requires another parameter: the position of where the item should be inserted. This index parameter is actually the first one, while the item to be inserted is the second.

a_list_variable.insert(index_value, item_to_add)
Here's an example:

my_list = [1, 2, 4]

# Oops! Forgot 3!
my_list.insert(2, 3)
print(my_list)
OUTPUT:

[1, 2, 3, 4]
In the example above, the value 3 is inserted into the my_list list at index 2. Using numeric values might be confusing for remembering which parameter is the index. So, below, you'll find some more examples.

my_list = [1, 2, 3, 5]

# add 'zero' to the beginning of the list
my_list.insert(0, 'zero')

# insert `four' at index 4
my_list.insert(4, 'four')

print(my_list)
OUTPUT:

['zero', 1, 2, 3, 'four', 5]
As you can see in the above examples, you can insert mixed data types into a list. When you insert a new value at the specified index position, the old value is moved to the next available index position. For example, above, when 'zero' was inserted at index 0, the value 1 moved to index 1, 2 moved to index 2, and so on.
____________________________________________________________________
# Removing an Item From a List
There will come a time when you need to remove items from a list. There are two ways to accomplish the task:

If you know the index of the item, you use the del command.

If you do not know the index, you use the .remove() function, specifying the value to delete.

Using either command above, you can only remove one item at a time.

When You Know the Index - del
If you know the index, you can remove an item from a list by using the del command. The item to be removed follows the command like so:

numbers = [1, 2, 3, 4]

# delete item at index 2
del numbers[2]
print(numbers)

# the position of value 4 has changed
# its index went from 3 to 2, due to the deletion

# delete the first item
del numbers[0]
print(numbers)

# delete the last item
del numbers[-1]
print(numbers)
OUTPUT:

[1, 2, 4]
[2, 4]
[2]
There are three uses of the del command above:

del numbers[2]
del numbers[0]
del numbers[-1]
The first one deletes the item at index 2, or the third item. As you can see in the comments, this results in the index changing for the last item, namely 4. Its index goes from 3 to 2.

The second deletion removes the first item by using index 0. The final one deletes the last item in the list using -1 as the index.

When You Don't Know the Index - .remove()
If you do not know the index of the item you wish to remove, you can use the remove command. This command is like the append and insert commands, where you put a period . after the variable, followed by the command and its parameter. The parameter for the remove command is the value of the item that you wish to remove.

Here's an example:

colors = ['red', 'blue', 'yellow', 'green']
colors.remove('yellow')
print(colors)
OUTPUT:

['red', 'blue', 'green']
As you can see above, the item with the value 'yellow' is removed from the list colors.

But what if there are multiple items in the list with the same value?

Good question! When a list contains the same value multiple times, the first item that matches will be removed, while the others will remain.

colors = ['red', 'blue', 'red', 'green']
colors.remove('red')
print(colors)
OUTPUT:

['blue', 'red', 'green']
Great! Now you know how to add and insert items into a list, as well as remove them. Next, you'll learn about a few new useful commands that you can use that are related to lists.
____________________________________________________________________
# Creating a List from a Range of Numbers
The function range() can be used to create a collection of numbers from a starting point to an ending point. It has three parameters: the starting value, the ending value (non-inclusive), and the size to increment between the starting and stopping values. Both the starting value and the step size parameters are optional.

Storing Range as a List
Since range() is a function, in order to use it as a list, it needs to be converted to a list using the list() function!

Check out the example below:

numbers = list(range(1, 11))
print(numbers)
OUTPUT:

[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
As you can see above, the numbers variable printed out as a list of numbers from 1 to 10 (remember the stop parameter of range is non-inclusive). The first line of code creates a list object from the range that's created with range(1, 11). You'll notice here that the default option to increment is 1 when it is not specified.

Storing Range as a Variable
The value of the range can also be stored as a variable:

the_range = range(1, 11)
numbers = list(the_range)
Range with No Start Value
You can also exclude the starting value for a range. If you do, it will start from 0 by default.

no_start_range = range(5)
numbers = list(no_start_range)
print(numbers)
OUTPUT:

[0, 1, 2, 3, 4]
Specify the Increment in the Range
The optional third parameter for range() specifies how to increment from the starting value to the next value and so on. So, for example, if you wanted only the even numbers between 1 and 10, you would do:

inc_by_2_range = range(2, 11, 2)
numbers = list(inc_by_2_range)
print(numbers)
OUTPUT:

[2, 4, 6, 8, 10]
Above, it start with 2 and ends at 11 (non-inclusive), but it uses a step size of 2. Here's another:

inc_by_10_range = range(0, 101, 10)
numbers = list(inc_by_10_range)
print(numbers)
OUTPUT:

[0, 10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
____________________________________________________________________
# Sorting a List
When storing data, your list may be created in an unpredictable order, as you cannot always control the order in which you receive data. However, there may come a time when you want to present the data in a particular order. To do so, Python provides an operation for sorting a list. The sort() function will take all of the elements of the list and place them in alphabetical or numerical order. After the sort() function is run on a list, the sequence of the list itself will change. It is a permanent change.

numbers = [2, 6, 3, 9, 1, 10]
strings = ['dog', 'cat', 'bird']

#sort numerically
numbers.sort()

# sort alphabetically
strings.sort()

print(numbers)
print(strings)
OUTPUT:

[1, 2, 3, 6, 9, 10]
['bird', 'cat', 'dog']
Here you can see the sort() function arranged the numbers list in numerical order starting with 1, while it also sorted strings alphabetically.

Sort in Descending Order
What if you wanted to reverse that order? Python gives you a way to do just that by adding reverse=True to the sort operation.

numbers = [2, 6, 3, 9, 1, 10]
numbers.sort(reverse=True)
print(numbers)
OUTPUT:

[10, 9, 6, 3, 2, 1]
Non-Permanent Sorting
What if you wanted to display the list in a sorted order, but did not want to affect the actual order of the list? This is when the sorted() function is useful! You can temporarily sort the elements of the list without affecting the actual list itself.

Here's an example:

numbers = [2, 6, 3, 9, 1, 10]

print("This is the original set of numbers: ")
print(numbers)

print("This is the sorted set of numbers: ")
print(sorted(numbers))

print("This is the original set of numbers again: ")
print(numbers)
OUTPUT:

This is the original set of numbers:
[2, 6, 3, 9, 1, 10]
This is the sorted set of numbers:
[1, 2, 3, 6, 9, 10]
This is the original set of numbers again:
[2, 6, 3, 9, 1, 10]
As you can see, the list can be sorted without changing the original list.

Great! Now it's time to learn about how to iterate over the items in a collection. You will do that often in programming.
____________________________________________________________________
# Iterating Over a Collection
What is iterating? Iteration is the act of repeating a process to generate a sequence of outcomes with the aim of approaching a desired goal, target, or result.

In the world of programming, when you have a collection of items, like a list, you can iterate over each item in the list to do something.

In Python, there are two common mechanisms that you can use to iterate through a list: the for loop, and the while loop.

For Loop
To understand how to use a for loop, consider a situation where you have a list of countries, and you want to print them out. Of course, you already know that you can print out the actual list. You've already seen this:

countries = ['USA', 'Canada', 'England', 'Ireland']
print(countries)
OUTPUT:

['USA', 'Canada', 'England', 'Ireland']
If, however, you wanted to print out each country individually, instead of all at once, then you would need to iterate over the list and print each country as you get to it.

The following code uses the for loop to do this:

countries = ['USA', 'Canada', 'England', 'Ireland']

# loop through list of countries using `for` loop
for country in countries:
    print(country)
OUTPUT:

USA
Canada
England
Ireland
Tip!
Don't forget to use proper indentation!

As you can see, each element in the list was printed on a new line.

Above, the variable countries is a list. country is a temporary variable that contains the value of each item in the list as it iterates over the list. The code below the line containing the for statement will be executed once per item. Since there are four countries in the countries list, this means that it will print() four times.

Did you notice the colon : after the for country in countries? Just like using an if or else keyword, a colon is required at the end of the for statement (but before the block of code that gets executed for each item in the list).

If you were to translate the for loop code to spoken language, it could be read as:

For each country in the list of countries, print the country.

Another Example
Looping, or iterating, is an important concept to understand. Undoubtedly, you will need to iterate over lists throughout your programming career. So, below you will find another example to help you gain a solid understanding of iteration using a for loop.

# 1. a list of numbers from 1-5
all_numbers = [1, 2, 3, 4, 5]

# 2. an empty list that will store even numbers
even_numbers = []

# 3. loop through `all_numbers` and add the even
# numbers to the `even_numbers` list
for the_number in all_numbers:
    # 4. if the number is even, add to `even_numbers`
    if the_number % 2 == 0:
        even_numbers.append(the_number)
    else:
        print("Ignoring the odd number: ", the_number)

# 5. print out `even_numbers`
print(even_numbers)
OUTPUT:

Ignoring the odd number: 1
Ignoring the odd number: 3
Ignoring the odd number: 5
[2, 4]
In the example above, there are numbered comments that will be discussed:

The list all_numbers is created first, and it contains numbers from 1 through 5.

An empty list variable named even_numbers is created. This list will, eventually, contain the list of even numbers of the all_numbers list.

The for loop iterates over each number in the all_numbers list variable. The variable the_number will contain the value of each number of the list as it loops through. A colon is required at the end of this line!

The four lines of code beneath this comment have the same indentation, so they are considered as one block of code that gets executed for each item in the list. First, it tests whether the current number of the list is even (the_number % 2 == 0), and if it is, it adds it to the even_numbers list. Otherwise, it prints out a message with the odd number.

Once the for loop has finished iterating over the list of all_numbers, the even_numbers list should now contain the even numbers, and it is printed to the console.

In both examples above, the country and the_number variables in the for loops are named as desired. They could have been named any way you'd like, but you should name them such that they make sense. Since the variable name for the list is plural (e.g. "countries"), the temporary variable that holds the current value while looping should be singular (e.g. "country"), since it represents an individual item.

That's it! Next, you'll see another way you can iterate over a list.
____________________________________________________________________
# While Loop
The while loop is another mechanism for iterating over the items of a list; it is similar to a for loop, but there is a noteworthy difference.

A for loop takes a collection of elements and executes a command or series of commands once for each element in the collection. On the other hand, a while loop will run as long as, or while, a certain condition is True.

For example, you could use a while loop to count up through a series of numbers:

a_number = 1
while a_number <= 5:
  print(a_number)
  a_number += 1
OUTPUT:

1
2
3
4
5
____________________________________________________________________
# Iterating over a List with a While Loop
Great! As you can see, the while loops doesn't require a list variable to be used, but it can be used to iterate over a list like in the example below. The example is the same one as above that grabbed the even numbers from a list and put it in another list — it just uses a while loop instead of a for loop:

all_numbers = [1, 2, 3, 4, 5]
even_numbers = []

# use a while loop to iterate over the list
current_position = 0
while current_position < len(all_numbers):
    the_number = all_numbers[current_position]
    if the_number % 2 == 0:
        even_numbers.append(the_number)
    else:
        print("Ignoring the odd number: ", the_number)
    current_position += 1

print(even_numbers)
OUTPUT:

Ignoring the odd number: 1
Ignoring the odd number: 3
Ignoring the odd number: 5
[2, 4]
____________________________________________________________________
# Terminating a For Loop
When you need to terminate a loop before it completes iterating over a list using a for loop or a test condition is met, you would use the break statement. Take a look at the sample below:

for letter in "Sally":
  if letter == "l":
    break
  print("Current letter: " + letter)

print("The loop is over.")
OUTPUT:

Current letter: S
Current letter: a
The loop is over.
In the example above, the loop is terminated using break when the letter l is discovered. The line of code after the break will not be executed when break is called.

Terminating a While Loop
Here's an example using break within a while loop:

a_number = 7

while a_number > 0:
    print("Current number value is:", a_number)
    a_number -= 1
    if a_number == 4:
        break

print("The loop is over.")
OUTPUT:

Current number value is: 7
Current number value is: 6
Current number value is: 5
The loop is over.
As you can see, the break statement stops the loop when the a_number variable reaches the value of 4.

Skipping an Iteration of a Loop
Using a break statement allows you to exit a loop immediately. But what if you need to skip an iteration? Consider an example where you're looking for a specific item within a list. For each item that does not match, you don't need to do anything, so just skip it. The key term for this is continue.

everyone = ['Sally', 'Billy', 'Mary', 'Bob']
looking_for = 'Mary'

for person in everyone:
    if person != looking_for:
        continue
    print("Found " + looking_for + "!")
OUTPUT:

Found Mary!
The continue statement can be used in both while and for loops.
____________________________________________________________________
