question_one = "What is your name?"
answer_one = "My name is \"Billy\""
question_two = "How old are you?"
answer_two = "How old are you?"
answer_two = 30
# question_three = "How many months is that?"
# answer_three = 360

print(question_one)
print(answer_one)
print(question_two)
print(answer_two)
# print(question_three)
# print(answer_three)

my_string = "Here is a string"
my_integer = 843
my_float = 7.4

print(my_string)
print(my_integer)
print(my_float)

print("Hello World")
