# Class Created
class Stadium:
    """This is a class"""
    def __init__(self, name, city_state, capacity):
        """This is the class"""
        self.name = name
        self.city_state = city_state
        self.capacity = capacity

    def describe_stadium(self):
        print("The" + self.name + "stadium is located in " + self.city_state + " and holds " + self.capacity + " fans.")

    def sports_played(self, sport):
        print("The following sport is mainly played in this stadium: " + self.sport)

    def seats_available(self, seats):
        print("There are " self.seats + " seats still available for tonight's game.")

stadium1 = Stadium("Mercedes Benz Arena", "Atlanta, GA", "70,000")

stadium1.describe_stadium()
stadium1.sports_played("Football")
stadium1.seats_available("70,000")

