# PAGE 3 lesson 1- STRINGS
# string is text — words, greetings, titles, names, etc. 
# You saw how you can set a string, including using single and double quotes and 
# special characters like tabs and newlines.
# Concatenation means to combine. When concatenating strings, you use the + operator.
_____________________________________________________________________________
#turn the integers into strings with the str() function
# EXAMPLE:
day = 1
year = 2017
month = "August"

today_is = month + " " + str(day) + ", " + str(year)

print(today_is)

# ALTERNATIVELY, use the function str.format()
# EXAMPLE:
day = 1
year = 2017
month = "August"

today_is = str.format("The date is {} {}, {} ", month, day, year)

print(today_is)

OUTPUT WOULD BE: The date is August 1, 2017
_____________________________________________________________________________
#  TO MAKE ALL LOWERCASE or UPPERCASE:
# EXAMPLE:
my_message = "THESE ARE ALL CAPS"

print(my_message.lower())
print(my_message.upper())
_____________________________________________________________________________
#  Replacing Text in a String
# EXAMPLE:
experience = "this game is fun"
better_experience = experience.replace("fun", "awesome")

print(experience)
print(better_experience)
_____________________________________________________________________________
# Splitting aka delimiting Text Strings Into Substrings -  page 7 lesson 1
# EXAMPLE:
my_message = "Split these words for me"
split_at_spaces = my_message.split()

print(split_at_spaces)
OUTPUT:

The output is a list that has each word in its own set of quotes and separated by a comma.

['Split', 'these', 'words', 'for', 'me']
__________________

# Splitting with a Specified Separator
#  EXAMPLE
my_message = "apples,oranges,bananas"
split_at_commas = my_message.split(",")

print(split_at_commas)
OUTPUT:

['apples', 'oranges', 'bananas']
_____________________________________________________________________________
# FOR MORE STRING METHODS:
https://docs.python.org/3/library/stdtypes.html#string-methods
_____________________________________________________________________________

# Arithmetic Operators  - PAGE 8+9 - LESSON ONE
Operator	Operation	Description
+	        Addition	Adds the values on either side of the operator.
3 + 3 = 6
-	        Subtraction	Subtracts the right-hand operand from the left-hand operand.
3 - 3 = 0
*	        Multiplication	Multiplies both operands together.
5 * 5 = 25
/	        Division	Divides the left-hand operand by the right-hand operand.
9 / 3 = 3
%	        Modulo	Divides the left-hand operand by the right-hand operand and returns the remainder.
10 % 3 = 1 or 20 % 10 = 0
//	        Floor division	The division of operands where the result is the quotient in which the digits after the decimal point are removed. If one of the operands is negative, the result is floored or rounded away from zero.
9 // 2 = 4 or -11 // 3 = -4
**	        Exponential	Performs exponential calculation on operators.
10 ** 20 is read as 10 to the power of 20.
_____________________________________________________________________________

# TIP: ALWAYS USE PARENTHESIS SO THAT THESE GO IN THE FIRST ORDER JUST LIKE PEMDAS.
_____________________________________________________________________________

# ASSIGNMENT OPERATORS - PAGE 8+9 - LESSON ONE
Operator	Operation	    Description
=	        Assignment	    Assigns values from the right side operand to the left side operand.
a = 5 : assigns the value of 5 to the variable a
c = a + b : assigns the value of a + b to the variable c
+=	        Addition	    Adds the right operand to the left operand and assigns the result to the left operand.
c += a is equivalent to c = c + a
-=	        Subtraction	    Subtracts the right operand from the left operand and assigns the result to the left operand.
c -= a is equivalent to c = c - a
*=	        Multiplication	Multiplies the right operand by the left operand and assigns the result to the left operand.
c *= a is equivalent to c = c * a
/=	        Division	    Divides the left operand by the right operand and assigns the result to the left operand.
c /= a is equivalent to c = c / a
%=	        Modulo	        Gets the modulus of the two operands and assigns the result to the left operand.
c %= a is equivalent to c = c % a
//=	        Floor division	Performs a floor division and assigns the result to the left operand.
c //= a is equivalent to c = c // a
**=	        Exponential	    Performs an exponential calculation and assigns the result to the left operand.
c **= a is equivalent to c = c ** a
_____________________________________________________________________________

# Comparison Operators - PAGE 10 - LESSON ONE
Operator	    Comparison	    Description
==	            Equals	        If the values of the two operands are equal, then the condition becomes true.
3 == 3 would equal True, but 3 == 2 is False
!=	            Does not equal	If the values of the two operands are not equal, then the condition becomes true.
2 != 5 would equal True, because 2 does not equal 5
>	            Is greater than	If the value of the right operand is greater than the left operand, then the condition becomes true.
5 > 2 would be True, because 5 is greater than 2
<	            Is less than	If the value of the right operand is less than the left operand, then the condition becomes true.
2 <> would be False, because 2 is not less than 2
2 <> would be True, because 2 is less than 5
>=	            Is greater than or equals	If the value of the right operand is greater than or equal to the left operand, then the condition becomes true.
5 >= 2 would be True, because 5 is greater than or equal to 2
<=	            Is less than or equals	If the value of the right operand is less than or equal to the left operand, then the condition becomes true.
2 <=> would be True, because 2 is less than or equal to 2
_____________________________________________________________________________
# COMPARISON OPERATOR EXAMPLES WITH BOTH NUMBERS AND STRINGS

Code Examples
Here are some code examples you can try:

my_burger_price = 15

is_fifteen_dollars = my_burger_price == 15
# is_fifteen_dollars = `True` - price equals 15

is_not_twenty_dollars = my_burger_price != 20
# is_not_twenty_dollars = `True` - price does not equal 20

is_affordable = my_burger_price <= 10
# is_affordable = `False` - price is NOT less than or equal to 10

is_pricey = my_burger_price >= 15
# is_pricey = `True` - price is greater than or equal to 15

your_burger_price = 20

my_burger_costs_more = my_burger_price > your_burger_price
# my_burger_costs_more = `False` - your price is greater than mine

my_burger_costs_less = my_burger_price < your_burger_price
# my_burger_costs_less = `True` - my price is less than yours
Comparison Operators with Strings
You can use comparison operators with strings in addition to numbers:

my_name = "Sally"
your_name = "Billy"
some_name = "Sally"

print(my_name == your_name)
print(my_name != your_name)
print(some_name == my_name)

print("---")

my_name = "Joe"   # uppercase j
some_name = "joe" # lowercase j

print(my_name == some_name)
print(my_name.upper() == some_name.upper())
OUTPUT:

False
True
True
---
False
True
_____________________________________________________________________________

# Tip!
The assignment operator = is not the same as the comparison operator ==. 
The double equals is for string comparisons, while the equals is for numeric comparisons.

_____________________________________________________________________________

# LESSON 1 - PAGE 11 - USING "AND"
_____________________________________________________________________________

# LESSON 1 - PAGE 11 - USING "OR"
_____________________________________________________________________________

# LESSON 1 - PAGE 11 - USING "NOT"
_____________________________________________________________________________

# LESSON 1 - PAGE 11 - "COMBINING NOT, AND, OR"
Combining Logical Operators

# EXAMPLE:
Consider an example where someone can watch a movie if:

they are at least 18 years of age, and they have at least $15
OR, they are a friend and have at least $5
they must NOT have any food, regardless of the above
You can code this into Python in the following way:

my_age = 17
my_money = 7
is_friend = True
has_food = False

can_watch_movie = not has_food and ((my_age >= 18 and my_money >= 15) or (is_friend and my_money >= 5))

print(can_watch_movie)

_____________________________________________________________________________

# Indentation - LESSON 1 PAGE 18

Now that you've learned about boolean values and comparison operators, you can make decisions and control the flow of your programming. However, before you dive into decision-making, you need to understand how indentation works in Python.

In Python, whitespace is extremely important. The whitespace at the beginning of a line — which is referred to as indentation` — is what indicates which blocks of code go together. Indentation, which is just spaces or tabs at the beginning of a line, is used to determine the grouping of statements.

What this means is that statements that go together must have the same indentation. Each set of statements is referred to as a block. If you have the indentation wrong, your program will throw an error. Take a look at the example below:

my_message = "Hello World"
  print(my_message)
OUTPUT:

File "/Users/andrewstefanik/Desktop/my_Python/lesson_2.py", line 2
    print(my_message)
    ^
IndentationError: unexpected indent
When you run the above code, Python will detect an error and output the location and cause of the error. In this case, it is an IndentationError that is caused by the extra whitespace before the line containing the print operation.

Tip!
When writing Python code, the official recommendation is that indentation should be four spaces. With nested indentations, each indentation should be four spaces.

_____________________________________________________________________________

# Decision-Making - LESSON 1 PAGE 19
As you write programs in Python, you will undoubtedly encounter situations that will require making decisions. Programming often involves checking a certain set of conditions and choosing an action based upon those conditions. This is done in code much like in real life. Consider the following example:

A person can watch a movie if they have $10

This can be translated to Python pretty easily:

person_money = 12

if person_money >= 10:
  print("This person can watch the movie")
The output of the above code will be "This person can watch the movie." Why? Because they have $12, which is more than $10. The text is printed to the console only if the variable person_money has a value that is greater than or equal to 10, because you are only going to execute that command if the first statement is true.

What if you changed the value of person_money to 8, as shown below?

person_money = 8

if person_money >= 10:
  print("This person can watch the movie")
Well, nothing gets printed to the console. But why?

The condition test of whether person_money >= 10 fails, so the line to print is skipped. This is how if statements work. The thing only happens when the condition is true.

General if syntax:
When using if, the syntax is the following:

if <condition>:
  <operations>
The above is generic code, so it won't run. But it gives you the general format of how things should be written, and you will fill in the <> with your own conditions and operations. You will always start with the keyword if, and then follow that with the condition to test. In the earlier example, the condition that was being tested was whether person_money was at least $10 or more.

Following the condition, you'll find a colon (:). A colon is required after the if and condition tests, or it won't run. Python will be thinking that everything following is conditional, and will never recognize that it needs to stop and do the operation without that colon! You can think of the colon like a stopsign. Without stop signs on the road, everyone would just continue driving forward forever without recognizing that there is a need to stop driving, look both ways, and then proceed in another direction.

Remember that the block of operations to be performed IF the condition is met (true) is indented to the right. Python will also be angry if you forget that indent; luckily VSC will indent for you automatically when you include the colon. So get the first part right, and you should automatically get the second part right as well!

else
In the example above, the print operation is only performed if the condition is true. So, what if you wanted to print something if the condition fails? Like to tell them "Sorry, but you don't have enough money." This is where the else keyword comes into play.

person_money = 8

if person_money >= 10:
  print("This person can watch the movie")
else:
  print("Sorry, but you don't have enough money")
The output of the above code will be "Sorry, but you don't have enough money", because person_money is not greater than or equal to 10. It is something else.

So, both possible outcomes are handled above: they either have enough money, or they don't. Either way, the appropriate message is printed to the console.

Syntax for else
The else statement is aligned with the if statement (the indentation is the same). As well, the operation that is performed for the else block is indented like for the if statement.

The else statement also requires the use of the colon after the keyword.

elif
Finally, if there are more than two possible outcomes, you can use the elif statement. Consider the following scenario:

If your age is 18 or higher, you can watch R-rated movies. If your age is 13 or higher, you can watch PG13-rated movies. If your age is less than 13, you can only watch G-rated movies.

Below, you'll find the Python code to represent the above:

person_age = 18

if person_age >= 18:
  print("I can watch an R-rated movie")
elif person_age >= 13:
  print("I can watch a PG13-rated movie")
else:
  print("I can watch a G-rated movie")
The elif statement is essentially a combination of two words: else and if. Like an if statement, a condition test must follow the elif statement. And, like both if and else, a colon must reside at the end of the line for elif statements. Similarly, the operations must be indented like the other blocks.

The order in which you test the conditions can matter. The output from the above example is "I can watch an R-rated movie", which is what you would expect given the value of person_age (18). However, what happens if you change the order of condition tests?

person_age = 18

if person_age >= 13:
  print("I can watch a PG13-rated movie")
elif person_age >= 18:
  print("I can watch an R-rated movie")
else:
  print("I can watch a G-rated movie")
The output of the above would be "I can watch a PG13-rated movie", which is different than the previous example. This is due to the change in sequence of the checks. Since the first condition (person_age >= 13) is true, it succeeds, printing out the message about the PG-13 movie. The remainder of the checks are skipped, because the first one was satisfied.

Now, try the following:

person_age = 5

if person_age >= 18:
  print("I can watch an R-rated movie")
elif person_age >= 13:
  print("I can watch a PG13-rated movie")
else:
  print("I can watch a G-rated movie")
In the above code, the first test is whether the age is >= 18, which is false (5 < 18). So, it moves to the next test. However, this test fails, as well, since 5 is less than 13. Thus, the final else block is hit and the print operation is performed (there is no test for the final else).

_____________________________________________________________________________


