# What Is a Function?
A function is a re-usable block of code that, when called, performs a series of operations that are related to a specific task. A function is given a name that you use elsewhere when you wish to perform that series of operations. Using functions improves code readability and decreases development time. The use of functions also reduces maintenance efforts, since logic is grouped into functions instead of being littered throughout the application. If you need to make a change, it's much easier to change one location instead of 50.

Take a look at the code below which defines a function. Each piece will be discussed:

def greeting():
    """This function prints a greeting"""
    print("Hello!")

greeting()
OUTPUT:

Hello!
__________________________________________________________________________________
# Providing Data to a Function
As you build functions, you'll find that in order for the function to perform its operations, it may require data. In the previous example, the greeting function did not require any data. However, below, you'll find a new function definition that does.

def increment(value):
    """This function increments a value"""
    print("Old value =", value)
    value += 1
    print("New value =", value)

increment(10)
OUTPUT:

Old value = 10
New value = 11
__________________________________________________________________________________
# Function Parameters
In the definition of the increment function above, you should see that there is now a variable name nestled between the parenthesis:

def increment(value):
The value variable is called a parameter of the function. A function can have zero or more parameters, and the sequence of the parameters is your choice (although it will matter later).

Inside of the function's definition, these parameters can be used like any other variable. However, if you change the value of the parameter, it will only remain changed within the function's definition. You'll learn more about this shortly.

When a function has parameters, anytime that function is used, the parameters must be provided. The last line of the above sample code shows how the function is invoked and passed its required input.

increment(10)
If a value for the parameter is left out of the call to the function, it will produce an error (NOTE: the # ... below means that the other code was left out in order to highlight the relevant code; you will see this from time-to-time in this course):

# ...
increment()
OUTPUT:

Traceback (most recent call last):
  File "/Users/username/Desktop/my_Python/lesson_5.py", line 7, in <module>
    increment()
TypeError: increment() missing 1 required positional argument: 'value'
__________________________________________________________________________________
# Arguments to a Function
When a function requires input, its definition includes parameters, as you saw above. When you make use of the function by calling/invoking it, you must provide the required input. The data that you provide for each parameter is called an argument.

The increment function had one parameter value:

def increment(value):
In the call to increment, a single value 10 was provided: That is the argument.

Take a look at another example (there is no need to try this code yourself):

def my_function(how_many, of_what, it_tastes):
    # do stuff
Above, the my_function definition includes three parameters: how_many, of_what, and it_tastes. Below is the code that calls the above function:

my_function(10, 'apples', 'yummy')
The call to my_function includes three arguments — 10, 'apples', and 'yummy' — one for each parameter. 10 is the argument corresponding to the how_many parameter; 'apples' is the argument corresponding to the of_what parameter; 'yummy' is the argument corresponding to the it_tastes parameter.
__________________________________________________________________________________
# Optional Function Parameters
Functions can have optional parameters. This is accomplished by providing a default value for a parameter. To illustrate, take a look at the code below that modifies the increment function to take a second parameter named: step_size. The call to the function has also been modified to provide the required argument for the new parameter.

def increment(value, step_size):
    """This function increments a value"""
    print("Old value =", value)
    value += step_size
    print("New value =", value)

increment(10, 5)
OUTPUT:

Old value = 10
New value = 15
__________________________________________________________________________________
# To illustrate an optional parameter, the step_size parameter is given a default value using the assignment operator = and the default value. Below, the default value of the step_size parameter is 1.

def increment(value, step_size=1):
    """This function increments a value"""
    print("Old value =", value)
    value += step_size
    print("New value =", value)

increment(10,5)
increment(10)
OUTPUT:

Old value = 10
New value = 15
Old value = 10
New value = 11
Now, there are two calls to the increment function:

increment(10,5)
increment(10)
__________________________________________________________________________________
# Keyword Arguments
Above, you saw that you must provide arguments to a function in the same sequence as expressed in the function's definition. Each of these arguments is referred to as a positional argument.

However, arguments can also be provided as a key-value pair, which means the order is no longer relevant. To illustrate take a look at the change to the call to the increment function below:

increment(value=2, step_size=2)
value=2 and step_size=2 are each a keyword argument; the key and value are both provided.

If the sequence is changed, it will still work and produce the same output:

increment(step_size=3, value=3)
As you can see, when you use keyword arguments, the sequence of the function's parameters is irrelevant.
__________________________________________________________________________________
# Returning Data From a Function
def increment(value, step_size=1):
    """This function increments a value"""
    return value + step_size

new_value = increment(5, 3)
print("The new value is", new_value)
OUTPUT:

The new value is 8
In the definition of the increment function, take a look at the one line of code (not the docstring):

return value + step_size
To return a value from a function, you use the return keyword followed by the value, variable, or expression.

When increment is called, the value returned by the function is captured in the new_value variable, which you can see as it's printed to the console.

Here's another example:

def sum(x, y):
    """This function sums the inputs"""
    return x + y

result = sum(10, 15)
print("The sum of 10 and 15 is", result)
OUTPUT:

The sum of 10 and 15 is 25
This time, the sum function returns the sum of x and y. The result variable is assigned this returned value, and it is added to the message printed to the console.

Take a look at the function below that returns a tuple of dictionaries:

def get_settings():
    """This function returns two dictionaries as a tuple"""
    dict1 = {'name': 'Bob', 'color': 'blue'}
    dict2 = {'name': 'Sally', 'color': 'red'}
    return (dict1, dict2)

tuple = get_settings()
print(tuple)
OUTPUT:

({'name': 'Bob', 'color': 'blue'}, {'name': 'Sally', 'color': 'red'})

Returning "Nothing" From a Function
All functions actually return a value, whether you specify it or not. If there is no explicit return statement, the function returns None, which is another Python keyword.

The None keyword is a special type in Python that represents nothingness. If a variable has a value of None, it ultimately means it has no value.

Take a look at the code below. It contains the first function that you saw in this lesson — greeting() — which does not return anything explicitly.

def greeting():
    """This function prints a greeting"""
    print("Hello!")

print(greeting())
OUTPUT:

Hello!
None
As you can see in the output, when the "result" of the greeting() call is printed to the console, it prints the value None. You can see this below the first line of the output, where "Hello!" is printed.
__________________________________________________________________________________

# Local Variables and Scope

When declaring variables inside of a function, they are not related to any other variable with the same name that is used outside of that function; this means the variable names are considered local to that function. This is known as the scope of the variable. All variables have the scope of the block that they are declared in, starting from the definition of the function.

When talking about scope, all variables in a program may not be accessible in all locations of that program. It all depends on where the variable was declared. The scope of a variable determines where that variable can be accessed. The two basic scopes of variables in Python are global and local.

What this means is that local variables can be accessed only inside the function in which they are declared, whereas global variables can be accessed throughout the program by all functions. When a function is called, the variables inside that function are brought into scope.

TAKE AWAY: - Variables that are defined inside a function body have a local scope, and those defined outside have a global scope.

Let's take a look at a few examples:

# this `user` variable is declared outside of the function
user = 'Andrew Jones'

def my_function(first, last):
    # this `user` variable is declared inside of the function
    # and is unrelated to the `user` variable declared outside of the function
    user = first + ' ' + last
    return user

print(user)
What do you think will be printed when the print function is executed?

OUTPUT:

Andrew Jones
The user variable that was declared outside of the function is printed. Now, if you want to print the user variable in the function you would need to invoke the function like so:

print(my_function('John', 'Smith'))
OUTPUT:

John Smith
Here you can see that the function was invoked and the user variable inside of the function is used to store the new name.

In the following example, the global variable user will be used inside of the function.

# The user variable is in global scope
user = "Andrew Jones"

def the_user():
    """Return the value of global variable user"""
    # The global variable user is returned
    return user
Now, when the function is invoked the value of the global variable user will be used.

print(the_user())
OUTPUT:

Andrew Jones

# The Global Statement

y = 25

def my_function():
    global y

    print('y is', y)
    y = 5
    print('the new value of global y is', y)

my_function()
print('y is now', y)
When this code snippet is executed the output is:

OUTPUT:

y is 25
the new value of global y is 5
y is now 5
__________________________________________________________________________________
