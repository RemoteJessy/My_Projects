#Part 1

#Create two dictionaries to represent two pets

Logan = {
    'Type' : 'Cat',
    'Color' : 'Black and white',
    'Nickname' : 'Logi',
    'Owner' : 'Jessenia'
}
Tritan = {
    'Type' : 'Goldfish',
    'Color' : 'Black',
    'Nickname' : 'Tritan',
    'Owner' : 'Jessenia'
}
#Iterate over each dictionary to print each key-value pair on one line.
for key, value in Logan.items():
    print(key,":  \t", value)
for key, value in Tritan.items():
    print(key, ":  \t", value)

# Part 2

# Add three dictionaries representing a city around the world.

england = {'Capital': 'London'}
france = {'Capital': 'Paris'}
belgium = {'Capital': 'Brussels'}
england['Population'] = '68.2 Million'
england['Interesting Fact'] = 'Sparkling wine was invented in England.'
england['Top Language Spoken'] : 'English'
france['Population'] = '67 Million'
france['Interesting Fact'] = 'French was the official language of England for about 300 years'
france['Top Language Spoken'] = 'French'
belgium['Population'] = '11.6 Million'
belgium['Interesting Fact'] = 'Belgians are crazy about football.'
belgium['Top Language Spoken'] = 'Dutch'

for key, value in england.items():
    print(key,": ", value)

for key, value in france.items():
    print(key,": ", value)

for key, value in belgium.items():
    print(key,": ", value)

# Part 3

pizza_order = {
    'Customer Name' : 'Andrew',
    'Pizza size' : 'small',
    'Crust type' : 'thin-crust'
    }

toppings = {
    'cheese': 'extra cheese',
    'meat': 'sausage',
    'Bacon': 'bacon'
}

print("Thank you for your order, " + pizza_order.get('Customer Name') + ". \nYou have ordered a " + pizza_order.get('Pizza size') + ", " + pizza_order.get('Crust type') + " pizza with the following toppings: \n" + toppings.get('cheese'), ",", toppings.get('meat'), ", and", toppings.get('Bacon'))
