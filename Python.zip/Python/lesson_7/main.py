def scoop_icecream(size, *toppings):
    """Give a summary of the ice cream cone you are making."""

    print("\nMaking a " + size + " ice cream cone with the following toppings:")
    for topping in toppings:
        print("- " + topping)

import icecream

icecream.scoop_icecream('small', 'sprinkles', 'chocolate', 'cherries')
icecream.scoop_icecream('large', 'peanuts')

# Using Functions from Imported Module
To call a function from an imported module, enter the name of the module you imported, followed by the name of the function separated by a dot(.).

Here is the syntax used to invoke a function from an imported module.

module_name.function_name()

# Importing Specific Functions
If a module is large, but you only need one function, there's no point plugging up memory with unnecessary code; you can import a single function. Below is the general syntax:

from module_name import function_name

# import as many functions as you would like from a module
from module_name import function_1, function_2, function_3

from icecream import scoop_icecream

scoop_icecream('small', 'sprinkles', 'chocolate', 'cherries')

# as
When you import a module, what if there's a function that is defined that has the same name as a function in the new file, or in another module you've already imported? Fortunately, Python provides a mechanism for giving an imported function an alias: as.

from icecream import scoop_icecream as scoop

scoop('small', 'sprinkles', 'chocolate', 'cherries')
The import statement above renames the function scoop_icecream() to scoop() in this specific file. Anytime you want to call scoop_icecream(), you can now call scoop() instead.

In general, the syntax is as follows:

from module_name import function_name as alias
Not only can functions be given an alias, but modules can be given an alias as well. Giving a module a short alias like i for icecream allows you to call the module's functions more quickly. Calling i.scoop_icecream() is more concise than calling icecream.scoop_icecream().

import icecream as i

i.scoop_icecream('small', 'sprinkles', 'chocolate', 'cherries')
When giving the module an alias, remember that all the function names will retain their original names. Calling i.scoop_icecream() is not only more concise than writing icecream.scoop_icecream(), but also directs your attention from the module name and allows you to focus on the more descriptive names of the functions. The function names, which tell you what each function does, are more important to the readability of your code than using full module names.

The general syntax for assigning an alias to a module is:

import module_name as alias

# Importing All Functions
from icecream import *

scoop_icecream('small', 'sprinkles', 'chocolate', 'cherries')

# Importing Classes

from module_name import class_name[, more_class_names]|*

from module_name import function_name as function_alias, class_name as class_alias

# Python Standard Modules
Now that you understand modules, you will be introduced to Python's library of standard modules. To start off, Python includes two modules that are useful for interacting with the Python system itself. These modules are sys and keyword. The keyword module contains a list of all Python reserved keywords. The sys module allows you to explore many features including the Interactive Mode help system.

sys
To import this module, the syntax is the same as if you were importing a module you created.

import sys
Now that sys (or system) has been imported, you can access the version of Python:

import sys

print('Python Version:', sys.version)
OUTPUT:

Python Version: 3.6.2 (v3.6.2:5fd33b5926, Jul 16 2017, 20:11:06)
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)]
What if you wanted to locate the Python interpreter?

INPUT:

import sys

print('Interpreter Location:', sys.executable)
OUTPUT:

Interpreter Location: /Library/Frameworks/Python.framework/Versions/3.6/bin/python3
keyword
Like for sys, you need to import this module:

import keyword
With the keyword library, you can print out a list of Python's reserved keywords with the following syntax:

import keyword

print('Keywords: ')
for word in keyword.kwlist:
    print(word)
OUTPUT:

Keywords:
False
None
True
and
as
assert
break
class
continue
def
del
elif
else
except
finally
for
from
global
if
import
in
is
lambda
nonlocal
not
or
pass
raise
return
try
while
with
yield
You can also check to see if a word you'd like to use is a reserved keyword or not by using the iskeyword() method.

import keyword

print(keyword.iskeyword('def'))
OUTPUT:

True

# The math Module

math.ceil() - This function rounds up to the nearest integer.
math.floor() - This function rounds down to the nearest integer.
If you were to print out the results of a call to these functions, you would see that although they are whole number integers, the data type is still a float. So, instead of 4, you'd see 4.0, for example.

You'll also have access to functions like pow() and sqrt():

math.pow(x,y) - This function returns a float of x raised to the power y.
math.sqrt(x) - This functions returns a float of the square root of x.
Below you'll find an example of each of the above functions. Take note of the first comment to remind you about importing entire modules and the need for dot syntax.

# since the entire module is imported, the module name
# must precede the function names (dot syntax)
import math

# round 8.5 down using `floor`
print("Round the number 8.5 down: ", math.floor(8.5))

# round 8.5 up using `ceil`
print("Round the number 8.5 up: ", math.ceil(8.5))

# compute 5^10 using `pow`
print("5 to the power of 10 = ", math.pow(5, 10))

# compute the square root of 82 using `sqrt`
print("The Square Root of 82 is: ", math.sqrt(82))
OUTPUT:

8
9
5 to the power of 10 =  9765625.0
The Square Root of 82 is:  9.055385138137417

# The random Module
Python includes a random module that can be used to produce pseudo-random numbers once imported into a program. Below are a few of the functions that are available from the random module.

random.random() - Produces a single floating-point number between 0 and 1.0.
random.sample() - Produces a list of elements selected at random from a sequence. This function requires two arguments to specify the sequence to select from, and the length of the list to be produced. Using the range() function will allow you to specify a sequence as the first argument.
Using the random module, here's an example of using random.random():

import random

print("A random float between 0 - 1.0: ", random.random())
OUTPUT:

A random float between 0 - 1.0:  0.7939999233344973
Now, the second function random.sample():

import random

numbers = random.sample(range(1, 49), 7) # The first argument given is the range from 1 to 49. The second argument is how many numbers you want to be returned from that range.

print('Your lucky numbers are: ', numbers)
OUTPUT:

Your lucky numbers are:  [42, 43, 36, 6, 44, 31, 23]

# Activity 1
import math
import random

my_random = random.random() * 100
square_root = math.sqrt(my_random)

# NumPy
The use of NumPy allows a developer to perform the following operations:

Mathematical and logical operations on arrays.
Shape manipulation
Operations related to linear algebra.
To demonstrate NumPy, it must be installed using pip. Either open a terminal/command-prompt, or open the integrated terminal in VS Code. To install NumPy, enter the following into the terminal:

# To install NumPy, enter the following into the terminal:
For Mac users:

pip3 install numpy
For Windows users:

python -m pip install numpy


# To Use:

numpy.array

Below are a few examples using the numpy.array. As you should have expected, NumPy needs to be imported. The code below imports it with an alias of np.

import numpy as np

x = np.array([1,2,3])
print(x)
OUTPUT:
___________________________________
[1 2 3]
What about with more than one dimension?

import numpy as np

x = np.array([[1, 2, 3], [4, 5, 6]])
print(x)

OUTPUT:

[[1 2 3]
 [4 5 6]]
____________________________________

import numpy as np

x = np.array([1, 2, 3, 4, 5], ndmin=2)
print(x)
OUTPUT:

[[1 2 3 4 5]]

_____________________________________
# Accessing and Modifying Files

When reading and writing to a file in Python, you must first open the file. When finished using the file, it must be closed. Python file operations take place in a specific order.

Open a file
Read or write. Referred to as performing an operation.
Close the file.

______________________

# Opening And Closing A File

The Python library contains the built-in function open() to open a file. This function returns the file object often called a handle.

When using the open() function, it requires two string arguments: one to specify the name and location of the file, and the second to specify one of the following modes that determine how the file is opened:

File Mode	Operation
r	Open an existing file to read.
w	Open an existing file to write. Creates a new file if none exists or opens an existing file and discards all its previous contents.
a	Append text. Opens or creates a text file for writing at the end of the file.
r+	Open a text file to read from or write to.
w+	Opens a text file to write to or read from
a+	Open or creates a text file to read from or write to at the end of the file.
Once the file is open and you have a file object (what's returned from the call to open()), you can get different details about the file from the object's properties, such as:

Property	Description
name	Name of the opened file.
mode	Mode in which the file was opened
closed	Status boolean value of True or False
Go ahead and create a new file in the same folder as your current file in VSCode and save it as example.txt. This file will be used to read and write data.
___________________________________________________

file = open('example.txt', 'w')

print('File Name:', file.name)
print('File Open Mode:', file.mode)
Now, when you save this file and run it in the terminal, you should see the following:

File Name: example.txt
File Open Mode: w
Now, you're going to define a function that allows you to determine if a file is open or closed.

def status(file):
    if(file.closed != False):
        return 'Closed'
    else:
        return 'Open'
You also need to add another statement to file_test.py to display the current file status. Add the following line to the end of the code file

print('File Status:', status(file))
Your file, now, should look like the following:

file = open('example.txt', 'w')

print('File Name:', file.name)
print('File Open Mode:', file.mode)

def status(x):
    if (x.closed != False):
        return 'Closed'
    else:
        return 'Open'


print('File Status:', status(file))
Once you save the file and run it in the terminal, your output should be:

File Name: example.txt
File Open Mode: w
File Status: Open
Now, that you know how to open a file and view its open status, mode, and file name, it's time to close the file:

file.close()

print('File Status:', status(file))
Once the code above is added to the file_test.py file, you should have the following:

file = open('example.txt', 'w')

print('File Name:', file.name)
print('File Open Mode:', file.mode)

def status(x):
    if (x.closed != False):
        return 'Closed'
    else:
        return 'Open'


print('File Status:', status(file))

file.close()

print('File Status:', status(file))
Now you will see the additional output File Status: Closed once you run the script.

______________________________________________

# Reading From And Writing To Files

Once you have successfully opened a file, it can now be read or new text can be written to the file, depending on the mode associated with the call of the open() method. Using the read() method will return the entire content of the file, and the write() method adds content to the file.

Go ahead and either comment out or delete the code in your file_test.py file.

You are going to start with a variable named story. Then, you can write a short line for the beginning of your story. Be sure to end each line with the new line characters \n, as you will be concatenating other lines to this first one.

story = "Once upon a time there was\n"
Now that you have the beginning of your story, go ahead and add a few more lines.

story = "Once upon a time there was\n"
story += "a dog who loved to play ball.\n"
story += "This dog could run as fast as the wind.\n"
You should be able to print story and each line should print to the terminal.

Once upon a time there was
a dog who loved to play ball.
This dog could run as fast as the wind.
Since the story is complete, you can create a new file object and add the story to the file.

file = open('story.txt', 'w')
file.write(story)
Above, a new file named story.txt is created and opened in write mode. The second line writes what's stored in story to the file.

Now, you need to close the file when you're done:

file = open('story.txt', 'w')
file.write(story)
file.close()
Next, you're going to open the file again, but this time in read mode:

file = open('story.txt', 'w')
file.write(story)
file.close()

file = open('story.txt', 'r')
Finally, you'll display the contents of the text file and close the file:

file = open('story.txt', 'w')
file.write(story)
file.close()

file = open('story.txt', 'r')

for line in file:
    print(line, end = '')
file.close()
Your file_test.py file should contain the following code:

story = "Once upon a time there was\n"
story += "a dog who loved to play ball.\n"
story += "This dog could run as fast as the wind.\n"

file = open('story.txt', 'w')
file.write(story)
file.close()

file = open('story.txt', 'r')

for line in file:
    print(line)
file.close()
Once you save the file and run it in the terminal, you will see that a new file named story.txt was created in the same folder with your other files. As well, the story should be printed to the terminal. And, about that....

When you first open a text file in read mode, the file object that is returned can be iterated to print out each line. This is the for loop you see above.

Alternatively, you can read the contents in using the read() function of the file object. To try it, replace the following code:

for line in file:
    print(line)
with the following new code:

contents = file.read()
print(contents)
Saving and running the file will show you that the output to the terminal changed in format, but the contents of the file did not change. If you ran the program more than once, shouldn't the file contain the story multiple times?

No. Any time you open a file using the write mode, or 'w', it truncates the file to the beginning, overwriting everything that was there before.

If you want to add more text to an existing file, you'll need to use the append mode, or 'a'. To demonstrate, change the mode flag from w to a in your code:

file = open('story.txt', 'a')
Now, go ahead and save and run the file. You should now see the story twice in both the story.txt file and the console/terminal:

Once upon a time there was
a dog who loved to play ball.
This dog could run as fast as the wind.
Once upon a time there was
a dog who loved to play ball.
This dog could run as fast as the wind.

________________________________________

# Updating File Strings

A file object's read() method will, by default, read the entire contents of the file from index position zero to the very end at the index position associated with the final character. Optionally, the read() method can take an argument to specify how many characters it should read.

The position in the file, from which to read or at which to write, can be controlled using the file object's seek() method. The seek() method takes an integer argument specifying how many characters to move position as an offset from the start of the file.

You can discover the current position from within the file at any time using the file object's tell() method to return an integer location (which character).

When working with file objects, it is good practice to use the Python keyword with to group the file operational statements within a block. When doing file operations within a with block, after the final statement has completed, the file is closed for you.

In your file_test.py file go ahead and comment out any current code you have in the file or erase it.

Start by creating a string variable with the following value:

new_text = 'Python was conceived in the late 1990s by Guido van Rossum'
Next, add the statements to write the new_text string into a file and display the file's current status using a with block.

with open('updating.txt', 'w') as file:
    file.write(new_text)
    print('\nFile Now Closed?:', file.closed)
Next, add another print statement to check the file's new status.

print('File Now Closed?:', file.closed)
Next, add code to open the file once again and display its contents to confirm it now contains the entire new_text string.

with open('updating.txt', 'r+') as file:
    new_text = file.read()
    print('\nString:', new_text)
Now, add the following code to the end of the last with block. Each statement should be indented to match the previous two statements in the block. The first line of code print's the file's current position. The second statement moves the file's current position 33 characters toward the end of the file. The final line prints the file's current position again to show that it moved.

    print('\nPosition In File Now:', file.tell())
    position = file.seek(33)
    print('Position In File Now:', file.tell())
Next, add the following line to the same with block to write 1980s to the file at the current file position. This will overwrite what was there previously.

    file.write('1980s')
Finally, add three more statements to the with block to return to the start of the file and display its entire updated contents.

    file.seek(0)
    new_text = file.read()
    print('\nString:', new_text)
All of the new code combined is as follows:

new_text = 'Python was conceived in the late 1990s by Guido van Rossum.'
with open('updating.txt', 'w') as file:
    file.write(new_text)
    print('\nFile Now Closed?:', file.closed)
print('File Now Closed?:', file.closed)

with open('updating.txt', 'r+') as file:
    new_text = file.read()
    print('\nString:', new_text)
    print('\nPosition In File Now:', file.tell())
    position = file.seek(33)
    print('Position In File Now:', file.tell())
    file.write('1980s')
    file.seek(0)
    new_text = file.read()
    print('\nString:', new_text)
Once this file is saved, you will see a new file created with the new_text string added. You will also see the following output in the terminal:

OUTPUT:

File Now Closed?: False
File Now Closed?: True

String: Python was conceived in the late 1990s by Guido van Rossum.

Position In File Now: 59
Position In File Now: 33

String: Python was conceived in the late 1980s by Guido van Rossum.

________________________________________

# A file object's read() method will, by default, read the entire contents of the file from index position zero to the very end at the index position associated with the final character. Optionally, the read() method can take an argument to specify how many characters it should read.

The position in the file, from which to read or at which to write, can be controlled using the file object's seek() method. The seek() method takes an integer argument specifying how many characters to move position as an offset from the start of the file.

You can discover the current position from within the file at any time using the file object's tell() method to return an integer location (which character).

When working with file objects, it is good practice to use the Python keyword with to group the file operational statements within a block. When doing file operations within a with block, after the final statement has completed, the file is closed for you.

In your file_test.py file go ahead and comment out any current code you have in the file or erase it.

Start by creating a string variable with the following value:

new_text = 'Python was conceived in the late 1990s by Guido van Rossum'
Next, add the statements to write the new_text string into a file and display the file's current status using a with block.

with open('updating.txt', 'w') as file:
    file.write(new_text)
    print('\nFile Now Closed?:', file.closed)
Next, add another print statement to check the file's new status.

print('File Now Closed?:', file.closed)
Next, add code to open the file once again and display its contents to confirm it now contains the entire new_text string.

with open('updating.txt', 'r+') as file:
    new_text = file.read()
    print('\nString:', new_text)
Now, add the following code to the end of the last with block. Each statement should be indented to match the previous two statements in the block. The first line of code print's the file's current position. The second statement moves the file's current position 33 characters toward the end of the file. The final line prints the file's current position again to show that it moved.

    print('\nPosition In File Now:', file.tell())
    position = file.seek(33)
    print('Position In File Now:', file.tell())
Next, add the following line to the same with block to write 1980s to the file at the current file position. This will overwrite what was there previously.

    file.write('1980s')
Finally, add three more statements to the with block to return to the start of the file and display its entire updated contents.

    file.seek(0)
    new_text = file.read()
    print('\nString:', new_text)
All of the new code combined is as follows:

new_text = 'Python was conceived in the late 1990s by Guido van Rossum.'
with open('updating.txt', 'w') as file:
    file.write(new_text)
    print('\nFile Now Closed?:', file.closed)
print('File Now Closed?:', file.closed)

with open('updating.txt', 'r+') as file:
    new_text = file.read()
    print('\nString:', new_text)
    print('\nPosition In File Now:', file.tell())
    position = file.seek(33)
    print('Position In File Now:', file.tell())
    file.write('1980s')
    file.seek(0)
    new_text = file.read()
    print('\nString:', new_text)
Once this file is saved, you will see a new file created with the new_text string added. You will also see the following output in the terminal:

OUTPUT:

File Now Closed?: False
File Now Closed?: True

String: Python was conceived in the late 1990s by Guido van Rossum.

Position In File Now: 59
Position In File Now: 33

String: Python was conceived in the late 1980s by Guido van Rossum.

__________________________________