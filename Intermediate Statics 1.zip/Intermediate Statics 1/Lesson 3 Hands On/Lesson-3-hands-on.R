#Data imported via using File, import data
loans <- read.csv("C:/Users/lzela/Downloads/loans.csv")

#Install/Import library
library('gmodels')
library('dplyr')
library('tidyr')

#Part I-Does the term of the loan influence loan status? If so, how? 
#Independent Chi-Square
CrossTable(loans$term, loans$loan_status, fisher = TRUE, chisq = TRUE, expected = TRUE, sresid = TRUE, format = "SPSS")

#All expected values are way more than 5. The lowest is 388.
# The p-value of 0 is less than 0.05, so the term definitely influnces the status of the loans.

#Post Hoc analysis to see how the terms of the loans influences loan status.
# Terms of 36 months are about 77.4% paid off, while terms of 60 months are only 22.6% paid off.
# 14% of loans are charged off, 2.2% are current, and 82.8% are fully paid.



#Part II-How has the ability to own a home changed after 2009? 
#McNemar Chi Square
str(loans)
#Reformatting to a Date
loans$DateR <- as.Date(loans$Date, format="%m/%d/%Y")
#I have to seperate the pieces of the Date variable.
loans1 <- separate(loans, DateR, c("Year", "Month", "Day"), sep="-")
View(loans1)            


loans1$YearR <- NA
loans1$YearR[loans1$Year <= 2009] <- "Up to 2009"
loans1$YearR[loans1$Year > 2009] <- "After 2009"

CrossTable(loans1$YearR, loans1$home_ownership, fisher = TRUE, chisq = TRUE, mcnemar = TRUE, expected = TRUE, sresid = TRUE, format = "SPSS")
              
#Test Assumption - All expected values are >5 (lowest is 551).
# Results: p-value of 0 is less than 0.05, which means the results are significant.
#The ability has changed after 2009.

#Post Hoc
# All standard residuals are less than +/- 2, meaning the results are more or less no significant.
#Home ownership after 2009 went up to nearly 82%, compared to 18% before 2009.
# After 2009, 2,508 people own and 15,491 rent.
#Before 2009, 550 people owned and 3,408 rented.
#It looks like overall, more people rent than own whether up to or after 2009.
    
#Part III-The news just ran a story that only 15% of homes are fully paid for in America, 
#and that another 10% have given up on paying it back, so the bank has "charged off" the loan. 
#Does it seem likely that the data for this hands on came from the larger population of America?
#Goodness of chi-square

#Expected ratio of 15% fully paid/10% charged off/75% are current - Goodness of Chi-Sqaure

##Data wrangling
loans %>% group_by(loan_status) %>% summarise(count=n())

observed = c(3282, 502, 18173)
expected = c(.1, .75, .15)

chisq.test(x=observed, p=expected)

#The p-value is less than 0.05 (2.2e-16).
#This means the observed and expected value differ significantly.
#It seem unlikely that the data for this hands on came from the larger population of America.
