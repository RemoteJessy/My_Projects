#Data was imported via file, import data

#View data
View(Seattle_ParksnRec)

#Import and Download packages
library("rcompanion")
library("IDPmisc")

#Number of trips Fall
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.Fall)
# it is positively skewed. trying out suqared root.
Seattle_ParksnRec$X..of.trips.FallSQRT <- sqrt(Seattle_ParksnRec$X..of.trips.Fall)
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.FallSQRT)
#A little better, shifting towards the middle. Let's try LOG.
Seattle_ParksnRec$X..of.trips.FallLOG <- log(Seattle_ParksnRec$X..of.trips.Fall)
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.FallLOG)
#No, it's not perfect. However, I will accept this.

#Number of participants Fall
plotNormalHistogram(Seattle_ParksnRec$X..of.participants.Fall)
#This is slightly positively skewed. Perhaps with suqaring the root it can shift a little more center.
Seattle_ParksnRec$X..of.participants.FallSQRT <- sqrt(Seattle_ParksnRec$X..of.participants.Fall)
plotNormalHistogram(Seattle_ParksnRec$X..of.participants.FallSQRT)
#Wow, I don't know how much better this will get, but let's give LOG a shot!
Seattle_ParksnRec$X..of.participants.FallLOG <- log(Seattle_ParksnRec$X..of.participants.Fall)
plotNormalHistogram(Seattle_ParksnRec$X..of.participants.FallLOG)
#LOG wins again!

#Number of trips per year
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.per.year)
#Positively skewed. Let's square away!
Seattle_ParksnRec$X..of.trips.per.yearSQRT <- sqrt(Seattle_ParksnRec$X..of.trips.per.year)
plotNormalHistogram(Seattle_ParksnRec$X..of.trips.per.yearSQRT)
#A little better. Let's try LOG.
Seattle_ParksnRec2$X..of.trips.per.yearLOG <- log(Seattle_ParksnRec2$X..of.trips.per.year)
plotNormalHistogram(Seattle_ParksnRec2$X..of.trips.per.yearLOG)
#This is the best for for this variable. LOG it is!

#Number of participants for year
plotNormalHistogram(Seattle_ParksnRec$X..participants.per.year)
#It's slightly positively skewed. Let's try squaring it.
Seattle_ParksnRec$X..participants.per.yearSQRT <- sqrt(Seattle_ParksnRec$X..participants.per.year)
plotNormalHistogram(Seattle_ParksnRec$X..participants.per.yearSQRT)
#A bit better. Let's LOG
Seattle_ParksnRec$X..participants.per.yearLOG <- log(Seattle_ParksnRec$X..participants.per.year)
plotNormalHistogram(Seattle_ParksnRec$X..participants.per.yearLOG)
#Squaring is better, even though it still doesn't look as normal.
#Let's try Tukey!
Seattle_ParksnRec$X..participants.per.yearTUK <- transformTukey(Seattle_ParksnRec$X..participants.per.year, plotit=FALSE)
plotNormalHistogram(Seattle_ParksnRec$X..participants.per.yearTUK)
#This is the best one so far out of the three.

#increase.decrease.of.prior.year
plotNormalHistogram(Seattle_ParksnRec$increase.decrease.of.prior.year)
#It's actually a tad bit positively skewed. Let's tweak a tiny bit with square.
Seattle_ParksnRec$increase.decrease.of.prior.yearSQRT <- sqrt(Seattle_ParksnRec$increase.decrease.of.prior.year)
plotNormalHistogram(Seattle_ParksnRec$increase.decrease.of.prior.yearSQRT)
#Oh no! That's worse. Let's leave it as is!

#Average...people.per.trip
plotNormalHistogram(Seattle_ParksnRec$Average...people.per.trip)
#Let's try squaring it
Seattle_ParksnRec$Average...people.per.tripSQRT <- sqrt(Seattle_ParksnRec$Average...people.per.trip)
plotNormalHistogram(Seattle_ParksnRec$Average...people.per.tripSQRT)
#This one looks better!