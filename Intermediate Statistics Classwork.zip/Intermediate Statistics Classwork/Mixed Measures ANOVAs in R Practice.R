#Load in Data
breakfast <- read.csv("C:/Users/lzela/Downloads/breakfast.csv")
View(breakfast)

library("rcompanion")
library("car")
library("dplyr")

#Question Setup
#Did those who ate breakfast in the morning improve their resting metabolic rate from baseline to follow up compared to those who skipped breakfast?  

#Data Wrangling
#Data wrangling for the mixed measures ANOVA is done exactly the same as it was for the repeated measures ANOVA.

#Testing Assumptions
#The assumptions for a mixed measure ANOVA are the same as the ones you learned for a repeated measures ANOVA. The only thing that differs is the sample size, because you now have two IVs.

#Analysis
RManova1 <- aov(repdat~(Treatment.Group*contrasts)+Error(Participant.Code/(contrasts)), breakfast6)
summary(RManova1)

#Post Hocs
#After finding such a load of bupkis above, so no need to worry about post hocs here!
