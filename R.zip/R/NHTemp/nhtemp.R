View(nhtemp)

first25 <- nhtemp[1:25]
last25 <- nhtemp[36:60]

print(first25)
print(last25)

library(reshape2)

t.obj <- t.test(first25, last25, paired = TRUE)
t.obj


#The problem to be solved
The problem to be solved is the difference between the averages
of the first and last 25 years of the data set.
#The hypotheses
There is no significant difference between the first and last
25 years of the data set, so we would fail to reject the null.
If the difference is very significant, then we would reject
the null.
#The results of the hypothesis test and the conclusion
The p-value is 0.0006383. Therefore, we reject the null hypothesis.