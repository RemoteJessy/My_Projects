#Loading in Libraries
install.packages("Ecfun")
install.packages("Ecdat")
library(Ecfun)
library(Ecdat)
library(ggplot2)
library(dplyr)
library(reshape2)
#Look at data and headings
View(Cigarette)
head(Cigarette)
________________________________________________________________
# Create boxplot of ave. # of packs per capital by state
ggplot(Cigarette, aes(x = state, y = packpc)) + geom_boxplot()
#The states that have the highest number of packs are KY, NH, and NC
#The states that have the lowest number of packs are UT, CA, NM

#Median
medianCigs <- Cigarette %>% select(year, packpc) %>% group_by(year) %>% summarise(medianPacks = median(packpc))
ggplot(medianCigs, aes(x=year, y=medianPacks)) + geom_point()
#Median scatter plot for the years 1985 to 1995.
#The median in 1985 was 118.6 and in 1995 was 92.3. The median value declined overall.

#Scatter Plot of price per pack VS # of packpc for all states & years.
ggplot(Cigarette, aes(x =avgprs, y=packpc)) + geom_point()
ggplot(Cigarette, aes(x =avgprs, y=packpc)) + geom_point() + geom_smooth(method=lm)
#Scatter plot to show the points for each year in a different color.
ggplot(Cigarette, aes(x=avgprs, y=packpc, color = year)) + geom_point()
#The price and the per capita packs are negatively correlated. 
#Although not well defined in a straight line, but the dip is obvious. 
#I expected this because over time, factories are making packs faster.
#Therefore, prices drop, and less employees are also needed.
#The color goes from brighter to darker, as the year increases. 
#The averageprc is going down throughout time.

#Extra: Correlation test
cor.test(Cigarette$packpc, Cigarette$avgprs, method="pearson", use="complete.obs")

#Linear Regression Model
ciglm <- lm(packpc ~ avgprs, Cigarette)
summary(ciglm)
#avgprs is going to decrease by -0.4, less than 0.05.
#Significant code is 0.001 which means the data is confirmed that it's significant.
#Adjusted R-squared:  0.3415 

#Adjust price of a pack of cig for inflation by dividing avgprs variable by the cpi variable.
InfPrice <- Cigarette %>% mutate(Price = avgprs/cpi)
View(InfPrice)

#Updated Scatter Plot
ggplot(InfPrice, aes(x = packpc, y = Price)) + geom_point()
ggplot(InfPrice, aes(x = packpc, y = Price, color = year)) + geom_point()


#Updated Linear Regression
regression2 <- lm(packpc~Price, InfPrice)
summary(regression2)

#Create a dataframe with just the rows from 1985.
Year1985 <- Cigarette %>% filter(year == 1985) 
#Create a dataframe with just the rows from 1995.
Year1995 <- Cigarette %>% filter(year == 1995)
#Get a vector of the number of packs per capita
nppc1 <- Year1985$packpc
nppc2 <- Year1995$packpc


#Use paired T-test to see if the # of ppc in 1995 were sig. diff than 1985.
t.obj <- t.test(nppc1, nppc2, paired=TRUE)
t.obj