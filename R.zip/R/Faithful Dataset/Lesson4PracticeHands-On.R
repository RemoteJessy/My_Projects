library(datasets)

faithful

eruption.times <- faithful$eruptions

summary(eruption.times)

wait.times <- faithful$waiting

mean(wait.times)
median(wait.times)
min(wait.times)
max(wait.times)

e.times <- faithful$eruptions

short <- e.times[e.times <= 3.0]
short

long <- e.times[e.times > 3.0]
long

mean(short)

mean(long)

sd(short)
sd(long)