rr = data.frame(rivers)
head(rr)
rivers <- c(735, 320, 325, 392, 524, 450)
rivers_df <- data.frame(rivers)
h <- ggplot(rivers_df, aes(x = rivers))
h + geom_histogram(binwidth = 80, fill = "thistle3", color = "cadetblue4") + ggtitle("Histogram of Rivers") + xlab("River Length (in miles)")

rr = data.frame(rivers)
head(rr)
ggplot(rivers_df, aes(sample = rivers)) + geom_qq()

rr = data.frame(rivers)
head(rr)
rivers <- c(735, 320, 325, 392, 524, 450)
rivers_boxplot <- ggplot(rivers_df, aes(x="", y = rivers))
rivers_boxplot + geom_boxplot() + xlab(" ")

summary(rivers)

IQR <- 505.5 - 341.8

outlier_range <- IQR * 1.5

505.5 + outlier_range
341.8 - outlier_range

