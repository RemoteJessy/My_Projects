IceSpheresDiameter = c(0.96, 1.51, 2.17, 3.85, 4.45, 6.02)

Diam = function(icesphereweight){
  ((2 / 2.54) * (icesphereweight / (0.92 * (4/3) * pi)) ^ (1/3))}

/*TRYING OUT CAT WITH MULTIPLE ANSWERS*/
for (icesphereweight in IceSpheresDiameter){
  d = Diam(icesphereweight)
  cat(icesphereweight, "radius=", d, "circumference")
}

/*CALCULATION FOR ONLY THE DIAMETER*/
for (icesphereweight in IceSpheresDiameter){
  d = Diam(icesphereweight)
  cat(icesphereweight)
}