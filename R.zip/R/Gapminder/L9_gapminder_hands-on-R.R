library(dplyr)
library(dplyr)
library(ggplot2)
library(gapminder)
library(gridExtra)

levels(gapminder$country)
# Choose five countries from the list
countries <- c("Finland", "Ireland", "Iceland", "New Zealand", "Sweden")
countrySpec <- gapminder %>% filter(country %in% countries)
# Lowest and max GDP per cap in 1952, 2007
countrySpec %>% filter(year %in% c(1952, 2007)) %>% arrange(gdpPercap)

ggplot(countrySpec) + geom_line(aes(x=year, y = lifeExp, color = country)) +
  xlab("Year") + ylab("Life Expectancy") + ggtitle("Life Expectancy by Country Overtime")

medianLifeExp <- gapminder %>% select(year,lifeExp) %>% group_by(year) %>% summarise(medlifeExp = median(lifeExp))

