#!/usr/bin/env python
# coding: utf-8

# # Independent t-Test in python

# In[9]:


#An independent t test is used when you have one independent variable that is categorical and a grouping variable, and one dependent continuous variable. Use an independent t-test when you want to determine whether the means of two different, unrelated groups are the same or different.


# # Import Packages

# In[1]:


import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import ttest_ind


# # Import Data

# In[2]:


hybrid2013 = pd.read_excel('hybrid2013.xlsx')
hybrid2013.head()


# # Test assumption - examine carclass 'C and M'

# In[3]:


hybrid2013.mpg[hybrid2013.carclass == 'C'].hist()


# In[4]:


# C is for compact cars testing above
# M is for mid-size hybrid cars testing below


# In[5]:


hybrid2013.mpg[hybrid2013.carclass == 'M'].hist()


# In[6]:


#It looks like neither of these are bell-shaped, and are thus not normal, but for the purposes of learning, you will continue.


# # Run Independent t-test with ttest_ind(data[column1], data[column2])

# In[10]:


ttest_ind(hybrid2013.mpg[hybrid2013.carclass == 'C'], hybrid2013.mpg[hybrid2013.carclass == 'M'])


# In[11]:


# Not a significant difference.


# # Exam the mean difference for both groups

# In[13]:


hybrid2013.mpg[hybrid2013.carclass == 'C'].mean()


# In[ ]:


The mean for Large cars is 40.75 mpg


# In[12]:


hybrid2013.mpg[hybrid2013.carclass == 'L'].mean()


# In[14]:


The mean for Large cars is 28.5 mpg


# # Conclusion: Driving a compact car will make more MPG than a large hybrid in 2013.

# In[ ]:




