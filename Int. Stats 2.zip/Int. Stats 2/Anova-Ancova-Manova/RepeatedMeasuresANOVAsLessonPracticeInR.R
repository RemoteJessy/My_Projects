#Importing Breakfast Dataset
breakfast <- read.csv("C:/Users/lzela/Downloads/breakfast.csv")
View(breakfast)

#Loading Libraries
library("rcompanion")
library("fastR2")
library("car")

#Question Setup
#Overall, regardless of whether participants ate breakfast or not, 
#did people in this study show improvement in their resting metabolic rate?   

#Quick Tip for ANOVAs
#In order to answer this question, your x, or independent variable, 
#will be the time factor - baseline or follow-up. 
#Your y, or dependent variable, will be the change in resting metabolic rate 
#from baseline to follow-up. 
#Remember:
#The IV will be categorical
#The DV will be continuous

#Data Wrangling
#May or may not be needed

#Remove extra rows
# Can be done in 2 ways: NaRV.omit() or subsetting the data, whici we'll do.
breakfast1 <- breakfast[1:33,]

#Reshape the data
keeps <- c("Participant.Code", "Treatment.Group", "Age..y.", "Sex", "Height..m.", "Baseline.Resting.Metabolic.Rate..kcal.d.", "Follow.Up.Resting.Metabolic.Rate..kcal.d.")
breakfast2 <- breakfast1[keeps]

#Reshaping Continued - doing for both baseline and follow-up data.
#Keep first 5 coumns that don't change by timepoint, and add it to the new
#columns of repdat and contrasts.
#Repdat will hold the actual data from baseline and 
#contrasts column will hold the info that says it was from the baseline timepoint.
breakfast3 <- breakfast2[,1:5]
breakfast3$repdat <- breakfast2$Baseline.Resting.Metabolic.Rate..kcal.d.
breakfast3$contrasts <- "T1"

#Do the same for the follow-up data
breakfast4 <- breakfast2[,1:5]
breakfast4$repdat <- breakfast2$Follow.Up.Resting.Metabolic.Rate..kcal.d.
breakfast4$contrasts <- "T2"

#rbind() them into one whole new dataset
breakfast5 <- rbind(breakfast3, breakfast4)

#Now you are all prepared to run a repeated measures ANOVA, 
#data shaping wise.

#Testing Assumptions Below

#Normality
plotNormalHistogram(breakfast2$Baseline.Resting.Metabolic.Rate..kcal.d.)

#Try the follow-up data:
plotNormalHistogram(breakfast2$Follow.Up.Resting.Metabolic.Rate..kcal.d.)

#Homogeneity of Variance
The tests you learned for homogeneity of variance for one-way ANOVAs will not work for repeated measures if you need to include any other information. In this case, you are not just looking for whether the resting metabolic rate increased over time, you are looking to see if it changed over time based on the condition (eating breakfast or skipping breakfast) the patient was placed in. So, a Levene's Test can be used instead to check for homogeneity of variance, using the function from the car library, leveneTest(). Here you will specify the variable information you are testing. Your y variable will go first, separated by a tilde and followed by your x variable and an asterisk, then your time variable. The time variable is contrasts, and remember that it represents time 1 (baseline) or time 2 (follow up). Altogether, you can read this code as a sentence like this: "Resting metabolic rate by treatment group over time."
leveneTest(repdat ~ Treatment.Group*contrasts, data=breakfast5)

#Correcting for Violations of Homogeneity of Variance
#If you had violated the assumption of homogeneity of variance, you could correct for it by running a BoxCox transformation on your data, or by running a more robust ANOVA, that can handle a violation of this assumption.
#Sample Size
#A repeated measures ANOVA requires a sample size of at least 20 per independent variable. You have that, so this assumption has been met.
#Sphericity
#The only way to test for sphericity in R is to take a multivariate approach and make it work for an ANOVA. At this time, that is a bit too complex, but it may be covered later.
#Which data format is required for repeated measures ANOVAs in R?
#The data format require for repeared measures ANOVAs in R is Long-wise
##The assumptions for one-way ANOVAs and repeated measures ANOVAs are the same.
#False-Repeated measures in ANOVAs also have the assumption of sphericity.

#Time for Analysis using the aov() function
RManova <- aov(repdat~contrasts+Error(Participant.Code), breakfast5)
summary(RManova)
#Under the Error:Within table (since this is a within subjects ANOVA, after all), the you will find your F value and the associated p value. Looks like there is not a significant effect of time on resting metabolic rate.

#Post Hocs
#The overall test wasnt significant, so no need to worry about post hocs.

#What part of the code when running an ANOVA indicates that it is repeated measures?
#Error()

#You see a line in your repeated measures ANOVA output that starts with Group:contrasts. What type of effect is that?
#Interaction Effect


