#ANCOVA Set Up in R

#Load Libraries
library("rcompanion")
library("car")
library("effects")
library("multcomp")

#rcompanion, as you know by now, is for assessing normality with easy, best-fit histograms.
#car library is both for assessing homogeneity of variance and for dealing with violations of said assumption.
#effects library will assist you in the creation of means adjusted by your covariate
#multcomp package is for conducting post hocs for ANCOVAs.

#Load in Data
#The data you will be conducting ANCOVAs upon is data about admissions into a graduate school program.
graduate_admissions <- read.csv("C:/Users/lzela/Downloads/graduate_admissions.csv")
View(graduate_admissions)

#Question Set Up
#Controlling for students' research participation in undergrad, does the rating of the students' 
#undergraduate university impact their chance of admittance into graduate school? 

#Note: For this question, the covariate is students' research participation in undergrad (Research), 
#since that is what you are controlling. The IV is the categorical variable, rated 1-5, of students' 
#undergraduate university (University.Rating), and the DV is the chance of admittance into graduate 
#school (Chance.of.Admit).

#Data Wrangling
#With this particular dataset, there is very little data wrangling required. All that is necessary is 
#to ensure that all categorical variables are factors, not integers, since the data type will throw 
#off the code for getting adjusted means and post hocs later (the ANCOVA itself will take the data in 
#any data type).

#Ensure the IV is a Factor
str(graduate_admissions$University.Rating)

#Convert to factor
graduate_admissions$University.Rating <- as.factor(graduate_admissions$University.Rating)

#Ensure the IV is a Factor (checking again)
str(graduate_admissions$University.Rating)

#Ensure the CV is a Factor
str(graduate_admissions$Research)

#Convert to factor
graduate_admissions$Research <- as.factor(graduate_admissions$Research)

#Testing Assumptions

#Normality
plotNormalHistogram(graduate_admissions$Chance.of.Admit)

#Let's try square just in case
graduate_admissions$Chance.of.AdmitSQ <- graduate_admissions$Chance.of.Admit * graduate_admissions$Chance.of.Admit
plotNormalHistogram(graduate_admissions$Chance.of.AdmitSQ)

#It looks like that was a pretty good choice, huh?
#Your data now meets the assumption of normality.

#Homogeneity of Variance
leveneTest(Chance.of.AdmitSQ~University.Rating, data=graduate_admissions)

#Unfortunately, this test is significant, which means that you have violated 
##the assumption of homogeneity of variance. You will learn how to correct for 
#this violation on the next page.

#Homogeneity of Regression Slopes
#Note:In order to test for homogeneity of regression slopes, you can run a one-way 
#ANOVA, with your covariate as the IV and the DV you were planning to use for 
#your ANCOVA. If the F test is non-significant, then you are good to go!
Homogeneity_RegrSlp = lm(Chance.of.AdmitSQ~Research, data=graduate_admissions)
anova(Homogeneity_RegrSlp)

#Sample Size
#The last assumption for ANCOVAs is sample size. There has to be at least 20 
#cases for every IV or CV. Since you will have one IV and one CV, you will need 
#at least 40 rows of data. In this case, you have 400 cases, so this assumption 
#is more than adequately met!

#Quiz Question:
#Jenny decides to create an ANCOVA model holding gender and age constant that 
#looks at the influence of horses on happiness levels for an equine therapy 
#trial. What is the minimum sample size she needs, per the assumptions of 
#ANCOVA?

#Running the Analysis
ANCOVA = lm(Chance.of.Admit~Research + University.Rating*Research, data=graduate_admissions)
anova(ANCOVA)

#When You've Failed Homogeneity of Variance
Anova(ANCOVA, Type="I", white.adjust=TRUE)
 
##########NOTES VERY IMPORTANT TO REMEMBER##########
#Types of ANOVAs for Type= Argument:
#Type I: This is automatically used when you use the aov() function you were taught in earlier lessons. The sum of squares are taken sequentially, which means that they are calculated in the order in which they are listed in the model.
#Type II: This type of ANOVA examines the effects of all the main effects, but ignores any interaction effects. So it is not suitable if you have more than one IV or CV in your model and want to determine how they interact.
#Type III: This is used only when you want to look at only some sums of squares effects. Basically, you can examine only the effects you specify by changing the options for contrasts. You can think of contrasts as built-in, planned post hocs. Specifying them in advance and being specific as to what you are looking for means that you have less Type I error, but they can be a pain to use. Hence they will not be covered in this course!
#Remember from previous lessons that the white.adjust=TRUE argument is what corrects for the violation of homogeneity of variance, so it is crucial to include.

#Post Hocs
postHocs <- glht(ANCOVA,linfct=mcp(University.Rating = "Tukey"))
summary(postHocs)

#Looking in the Pr(>|t|) column shows the p values associated with each of 
#these pairwise t-tests. It looks like there was a significant difference 
#between a university rated "1" and all other university ratings, a university 
#rated "2" and all other university ratings, but no differences between 
#universities rated "3," "4," or"5." What was higher between those differences 
#that were significant? Well, to determine that, you will need to examine the 
#means.

#Determine Means and Draw Conclusions
adjMeans <- effect("University.Rating", ANCOVA)
adjMeans

#Conclusion: So with these means, you can see here that a student who attended undergrad in a university rated a 1 has a significantly lower chance of being accepted (33%) when compared to all other university rating levels. A student who attended undergrad in a university rated a 2 also has a significantly lower chance of being accepted (42%) than anyone who attended a school that was rated a 3, 4, or 5. However, attending a school rated a 3, 4, or 5 did not significantly improve your odds of being accepted to graduate school.
#Drawing an overall conclusion from this data, you might say something like "as long as you attended a medium or better rated university for undergraduate, you have relatively good odds of being accepted to graduate school, but students who attended a poorly rated university are much less likely to be accepted, when controlling for the effects of having participated in research in undergrad."
