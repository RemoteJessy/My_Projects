###### MANOVA Preparation in R

####Load Libraries
library("mvnormtest")
library("car")

####Load in Data
kickstarter <- read.csv("C:/Users/lzela/Downloads/kickstarter.csv")
View(kickstarter)

####Question Set Up
#Does the country the project originated in influence the number of backers and the amount of money pledged?
#the independent variable will be the country the project originated in, country. This is a categorical variable.
#The two dependent variables will be the number of backers (backers) and the amount pledged (pledged). These variables are both continuous.

####Data Wrangling
#Although no data wrangling is actually required for the MANOVA itself, some wrangling is required to test for assumptions. In order to test for multivariate normality, you will need to create a dataset containing only your two dependent variables that is in a matrix format, and you will need to ensure that they are numeric. Unfortunately, the test for normality can only handle 5,000 records, so you will also need to limit your data to 5,000 rows as well.

#Ensure Variables are Numeric
str(kickstarter$pledged)
str(kickstarter$backers)

#Change to numeric
kickstarter$pledged <- as.numeric(kickstarter$pledged)
kickstarter$backers <- as.numeric(kickstarter$backers)

#Subsetting - only keep the two dependent variables, pledged and backers
keeps <- c("pledged", "backers")
kickstarter1 <- kickstarter[keeps]

#limit the number of rows (remember: maximum is 500)
kickstarter2 <- kickstarter1[1:5000,]

#Format as a Matrix
kickstarter3 <- as.matrix(kickstarter2)

#####Test Assumptions

####Sample Size
#The first assumption of MANOVAs is sample size. The rule of thumb is that you must have at least 20 cases per independent variable, and that there must be more cases then dependent variables in every cell. Meaning that there must be more than 2 cases for each country. Happily, both of these are fulfilled with a dataset of 323,746!

####Multivariate Normality
#We'll use kickstarter3 in the Wilks-Shapiro test. using mshapiro.test() from mvnormtest library.
mshapiro.test(t(kickstarter3))
#You have violated the assumption of multivariate normality if the p value is significant at p < .05, so unfortunately, these data do not meet the assumption for MANOVAs. However, for learning purposes, you will continue.

####Homogeneity of Variance for pledged
#Use levene's test from car to test for above on both DVs.
leveneTest(pledged ~ country, data=kickstarter)
####Homogeneity of Variance for backers
#Use levene's test from car to test for above on both DVs.
leveneTest(backers ~ country, data=kickstarter)
#RESULTS FROM BOTH: Unfortunately, neither variable met the assumption of homogeneity of variance, since they were both significant at p < .05. You have violated the assumption of homogeneity of variance, but you will proceed for now for learning purposes.

####Absence of Multicollinearity
#Typically, multicollinearity can be assessed simply by running correlations of your dependent variables with each other. A general rule of thumb is that anything above approximately .7 for correlation (i.e. a strong correlation) indicates the presence of multicollinearity. Check out the correlation between pledged and backers with a simple cor.test() function:
cor.test(kickstarter$pledged, kickstarter$backers, method="pearson", use="complete.obs")

####The Analysis
#You will use the function manova to run a MANOVA. Go figure!
MANOVA <- manova(cbind(pledged, backers) ~ country, data = kickstarter)
summary(MANOVA)
#Tada! You have run your first MANOVA. Looks like it was significant, too - there is a significant difference in backers and the funds they have pledged by country.

####Post Hocs
#But which dependent variable you ask? Well, that's where the post-hocs come in.

####ANOVAs as Post Hocs
summary.aov(MANOVA, test = "wilks")