#Part 1
#Quadratic Modeling in R
#Load libraries
library("ggplot2")
#Load Data
nonlinear <- read.csv("C:/Users/lzela/Downloads/nonlinear.csv")
View(nonlinear)
#Question Setup
# Try both methods with both sets of x's and y's to see what fits best

#Graph a Quadratic Relationship
quadPlot <- ggplot(nonlinear, aes(x = X1, y=Y1)) + geom_point() + stat_smooth(method = "lm", formula = y ~x + I(x^2), size =1)
quadPlot
# Eyeballing - it looks quadratic. It's half an upside down U, which still qualifies.

#Model the Quadratic Relationship (first the x which is the age)
FirstX <- nonlinear$X1^2
# Now we model the Y which is the length
quadModel <- lm(nonlinear$Y1~nonlinear$X1+FirstX)
summary(quadModel)
#Result from the summary: Looking at the overall F-statistic shown on the bottom and associated p-value, this quadratic model is significant!
#This method works great, the quadratic!


#Part 2
#Going to try Exponential Modeling now to see if this is this right fit.
#Exponential Modeling in R

#Load in Data (skip libraries because we don't need them here)
nonlinear <- read.csv("C:/Users/lzela/Downloads/nonlinear.csv")
View(nonlinear)

#Question Setup: Try both methods with both sets of x's and y's to see what fits best

#Exponential Modeling
exMod <- lm(log(nonlinear$X1)~nonlinear$Y1)
summary(exMod)

# Summary/Conclusion: 
#By looking at the bottom F-statistic and associated p-value, you see that this model is NOT significant! Only the p-value is significant, but not the F-statistic.
#This method is not so good, exponential modeling.


#Part 3
#Quadratic Modeling in R
#Load libraries
library("ggplot2")
#Load Data
nonlinear <- read.csv("C:/Users/lzela/Downloads/nonlinear.csv")
View(nonlinear)
#Question Setup
# Try both methods with both sets of x's and y's to see what fits best

#Graph a Quadratic Relationship
quadPlot <- ggplot(nonlinear, aes(x = X2, y=Y2)) + geom_point() + stat_smooth(method = "lm", formula = y ~x + I(x^2), size =1)
quadPlot

# Eyeballing - it looks quadratic. It's half a U, which still qualifies.

#Model the Quadratic Relationship (first the x which is the age)
SecondX <- nonlinear$X2^2
# Now we model the Y which is the length
quadModel2 <- lm(nonlinear$Y2~nonlinear$X1+SecondX)
summary(quadModel2)
#Result from the summary: Looking at the overall F-statistic shown on the bottom and associated p-value, this quadratic model is significant! Both F-statistic and P-value are significant.
#This is a good method, the quadratic.


#Part 4
#Going to try Exponential Modeling now to see if this is this right fit.
#Exponential Modeling in R

#Load in Data (skip libraries because we don't need them here)
nonlinear <- read.csv("C:/Users/lzela/Downloads/nonlinear.csv")
View(nonlinear)

#Question Setup: Try both methods with both sets of x's and y's to see what fits best

#Exponential Modeling
exMod <- lm(log(nonlinear$X2)~nonlinear$Y2)
summary(exMod)

# Summary/Conclusion: 
#By looking at the bottom F-statistic and associated p-value, you see that this model is NOT significant! The F-statistic is but the P-value is not. 
#Therefore, method is not so good, the exponential.
