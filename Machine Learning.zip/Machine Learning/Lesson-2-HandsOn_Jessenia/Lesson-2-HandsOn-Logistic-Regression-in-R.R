#Logistic Regression in R

#Load in Libraries
library("caret")
library("magrittr")
library("dplyr")
library("tidyr")
library("lmtest")
library("popbio")
library("e1071")
library("lattice")
library("ggplot2")
library("zoo")

# Load in Data
minerals <- read.csv("C:/Users/lzela/Downloads/minerals.csv")
View(minerals)

#Question Setup: Geologists have long known that the presence of antimony in a ground sample can be a good indication that there is a gold deposit nearby. In the attached data, you will find antimony (Sb) levels for 64 different locations, and whether or not gold was found nearby. The "gold" column is coded as 0 for no gold present, and 1 for gold present.
#Use logistic regression in R to create a prediction model that will give the probability of the presence of gold as a response.

#Data Wrangling: The one thing that absolutely has to be done before you can dive into logistic regression is the recoding of the outcome variable (DV) to zeros and ones. Currently, your wins and losses variable (W.L) has a W indicating a win and an L indicating a loss. In R, that just won't fly - you need this outcome variable to be numeric. The following code will create a new wins and losses column that will re-code this variable numerically:
#It's already done. Nest step.

##### Testing Assumptions #####

#1. Appropriate Sample Size
#The first thing you need to do to test for appropriate sample size is to create the logistic regression model.

#2. Run the Base Logistic Model: create a model first before you can ensure that it meets all the assumptions.
#glm is for logistic regession
mylogit <- glm(Gold ~ �..Antimony, data=minerals, family="binomial")
#This code should look somewhat familiar to you, as it stems from the same one as your linear regression. However, instead of just lm() you now use glm() and you need to specify family= . Here you have chose binomial because you are doing Binomial Logistic Regression. Place your dependent variable first, the new WinsR column that you re-coded, and then you will add your independent variable after the tilde. baseball is the name of your dataset.

#3. Predict Wins and Losses
#With that model created (but not interpreted!), you can make predictions about wins and losses. To do this, you will use the predict() function on your logit model first:
probabilities <- predict(mylogit, type = "response")
#Then convert your probabilities to a positive and negative prediction by having anything above .5 (half) be positive, and anything below .5 be negative. This will be done using the ifelse() function on the probabilities variable you just created, and it will be assigned to your baseball data set, as the column Predicted, so that you can later compare it with the recoded wins and losses column.
probabilities <- predict(mylogit, type = "response")
minerals$Predicted <- ifelse(probabilities > .5, "pos", "neg")


#4. Recode the Predicted Variable
#Just like you recoded wins and losses, you also need to recode your new Predicted variable:
minerals$PredictedR <- NA
minerals$PredictedR[minerals$Predicted=='pos'] <- 1
minerals$PredictedR[minerals$Predicted=='neg'] <- 0

#5. Convert Variables to Factors
minerals$PredictedR <- as.factor(minerals$PredictedR)
minerals$Gold <- as.factor(minerals$Gold)

#6. Create a Confusion Matrix
# And now you are finally ready to create a 2x2 chart, also known as a confusion matrix, which will not only test your sample size out, but will also provide some information on the accuracy of our prediction. Using the caret library, you will call the confusionMatrix() function, specifying that you want to compare your predicted values (PredictedR) to your actual data, which is the WinsR column.
conf_mat <- caret::confusionMatrix(minerals$PredictedR, minerals$Gold)
conf_mat
###### NOTE: 
#(top left)A loss was predicted and a loss happened.
#(top right)These are the cases predicted to fail the condition, which it did. There was more absence of gold than gold present.
#(bottom left)An absence of gold was predicted. There was more absence of gold than gold present.
#Gold was predicted to be present, but was actually more absent.
#(bottom right)Here, in this case there was more gold present.
#If any one of these four cells in the chart is below 5. We failed this assumption!
#Roughly 84% of the time, my predictions are correct.

#7. Logit Linearity
minerals1 <- minerals %>% 
dplyr::select_if(is.numeric)

#8. Pull the rename the column names to be fed into predictors.
predictors <- colnames(minerals1)

#9.Create the logit.
minerals1 <- minerals1 %>%
mutate(logit=log(probabilities/(1-probabilities))) %>%
gather(key= "predictors", value="predictor.value", -logit)

#10. Graph to assess for linearity.
ggplot(minerals1, aes(logit, predictor.value))+
  geom_point(size=.5, alpha=.5)+
  geom_smooth(method= "loess")+
  theme_bw()+
  facet_wrap(~predictors, scales="free_y")
This shows a nice strong linear relationship.

#11. Multicollinearity
#I only have one independent variable, skipping this step.

#12. Independent Errors
#Going to graph the residual over your index.

#13. Graphing the Errors
plot(mylogit$residuals)
#Looking pretty even distribution of points all the way across the x axis. We have met the assumption of independent errors.

#14. (Alternative to step above) Use The Durbin-Watson Test
#Testing to see whether I have independence of errors.
dwtest(mylogit, alternative="two.sided")
#This test is not statistically significant (> .05). The DW is above 1,so this is also a pass!

#15. Screening for Outliers
infl <- influence.measures(mylogit)
summary(infl)
#dfb/dffit are under 1 and hat is under .3. There aren't any outliers here.


#Running Logistic Regression and Interpreting the Output
#16. Calling logistic regression model/interpreting the output by asking for the summary:
summary(mylogit)
#Looking in the Coefficients table under �..Antimony, you see that the p value is significant at p <.05, which is great news.
#Estimate std. is 1.76 which means that for every unit increase in antimony, the log odds of finding gold are increased by 1.76.

#17. Graphing the Logistic Model
#Want to plot it? You can use the popbio library to do so with this code:
logi.hist.plot(minerals$�..Antimony,minerals$Gold, boxp=FALSE, type="hist", col="gray")