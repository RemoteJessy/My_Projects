#Load data
head(mtcars)

#Wrangle if you need to.  Here we don't.

#BACKWARD ELIMINATION
#Question Setup: Create a model that will use mpg as the response variable, and the other 10 columns of data as potential predictor variables. It is assumed that all 10 predictors don't really belong in the model.

#Get a Baseline: You will start by creating a function called FitAll that creates a linear model of all 10 predictor variables.
FitAll = lm(mpg ~ ., data = mtcars)
#mpg is your y, or response variable, and . means "all." Instead of saying mpg ~ ., you could have listed out all 10 predictor variables, as in "mpg ~ cyl + disp + hp + drat + ...". It is much easier to use the . rather than list them all out.

#Then get get the model summary, using the summary() function:
summary(FitAll)
# CONCLUSION IN THIS ONE: Although the overall p value at the bottom is significant, none of the individual predictors are, meaning that the model is probably not a good fit; the number of variables has just inflated the p value to the point of being significant, and what the independent variables are does not really matter.
#Once you have created a new model after backward elimination, you can compare the above model summary with all 10 predictors against what R has helped determine is the best fit.

#Try Backward Elimination
step(FitAll, direction = 'backward')
#  If you scroll up to the top of the output, right below the command, you will see this:
#Start:  AIC=70.9
#mpg ~ cyl + disp + hp + drat + wt + qsec + vs + am + gear + carb
#AIC stands for Akaike Information Criteria. It was invented by a Japanese statistician named Hirotugu Akaike in the 1970's. The AIC is a measure of relative quality of a model. However, it doesn't tell you if a model is any good or not. It simply helps you to compare two or more models against each other. When comparing two models, the model with the smaller AIC is generally accepted to be the better of the two models. In the case of the mtcars data, the start AIC of 70.9 is for the original model with all ten predictors.

#The bottom had the lowest AIC. So, let's see if it's any good.
#You can determine this by creating a new model with just those variables and then looking at the summary. You will create a new function called fitsome, which will just have the terms you are interested in:
fitsome = lm(mpg ~ am + qsec + wt, data = mtcars)
#There are a few things to note here from the above output:

#There are coefficients for just the three predictor variables, as well as an intercept.
#There is a multiple R2 = 0.8497. The practical interpretation of this is that the model explains 84.97% of the variation in the mpg variable, and there is another 15.03% of the variation that can be chalked up to noise or random error.
#There is an adjusted R2 = 0.8336. The adjustment is a modification that is supposed to take into account the number of terms in the model. For your purpose, you are more interested in the adjusted R2 than the multiple R2.
#There is an F-statistic (52.75 with 3 and 28 degrees of freedom) and a p value of 0.0000000000121 (this is represented in scientific notation in R) which indicates that the model is better than no model at all, because the p value is less than 0.05.
#So, have you really gained anything by doing the backward elimination? To the untrained eye, one might say "no gain." The R2 values are very similar, and both models are statistically significant. However, to the trained eye, you have adhered to the "Principle of Parsimony" and come up with an equally good (maybe marginally better) model that is much simpler. Further, now all of your individual predictors are significant! Mission accomplished.




#FORWARD ELIMINATION
fitstart = lm(mpg ~ 1, data = mtcars)

#Then run a summary for this model:
summary(fitstart)

#Begin Forward Selection
step(fitstart, direction = 'forward', scope = (~ cyl + disp + hp + drat + wt + qsec + vs + am + gear + carb))

#Or the other option is to utilize the fact that the FitAll model was defined before when you did the backward elimination approach, and simplify the command as follows:
step(fitstart, direction = 'forward', scope = (formula(FitAll)))

#Find the lowest iteration

#Examine the final model
#Do the same thing you did for the backward elimination model: build a model that only contains wt, cyl, and hp. You called it fitsome in the backward elimination model; call this one fitsome2:
fitsome2 = lm(mpg ~ wt + cyl + hp, data = mtcars)
#Look at the summary
summary(fitsome2)

#Conclusion: When you did the backward elimination model, you compared the initial model (all ten predictors) with the optimized model, and concluded that the models are similar as far as R2 is concerned, so the model with just 3 predictors seems preferable based upon simplicity alone. For the forward selection model, there really is no starting point sort of model. You just used the average mpg to get a starting point without any predictor variables.
#Nonetheless, take a look at the specifics of the forward selection model shown above:
#The multiple R2 = 0.8431. The practical interpretation of this is that the model explains 84.31% of the variation in the mpg variable, and there is another 15.69% of the variation that can be chalked up to noise or random error.
#There is an adjusted R2 = 0.8263. The "adjustment" is a modification that is supposed to take into account the number of terms in the model. For your purposes, you are more interested in the adjusted R2 than the multiple R2.
#There is an F-statistic (50.17 with 3 and 28 degrees of freedom) and a p value of 0.00000000002184 (this is represented in scientific notation in R) which indicates that the model is better than no model at all, because the p value is less than 0.05.
#The R2 for the backward elimination model and the forward selection model are similar. So, which one is better? One could argue that the AIC for the backward elimination model is slightly lower, so it must be better. But for all practical purposes, they are essentially the same. However, did you notice the terms in the predictor model are not the same? That is actually a pretty common result. The truth is that in many cases, there might not just be a single 'best' model that is far superior to the 'second best' model, but there might be a cluster of models that are essentially equally good.





#Hybrid Stepwise - Forward and Backward Selection
step(fitstart, direction="both", scope=formula(FitAll))

#Pick the lowest iteration











#Hierarchical Regression
#In hierarchical regression, you get to pick the variables that are being added or removed next, which allows you to make statements about how much variance is added "over and above" other variables. This approach can be quite useful especially when answering stakeholder questions about what variables are most important.

#Summary
#Stepwise regression has three basic approaches - backward elimination, forward selection, and a combination of the two.
#Backward elimination creates a model with all predictor variables included, and then removes them one at a time until the model is optimized.
#Forward selection starts with no predictor variables included, and adds them one at a time until the model is optimized.
#The combination approach starts with no predictor terms. Every time a term is either added or removed from the model, it is compared with the quality of all other models that either add a single predictor or remove a single predictor until the model is optimized.