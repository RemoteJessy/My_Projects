# INSTALL PACKAGES ###############
install.packages("car")
install.packages("caret")
install.packages("gvlma")
install.packages("predictmeans")
install.packages("e1071")
install.packages("lmtest")

# LOAD PACKAGES ##############
library("car")
library("caret")
library("gvlma")
library("predictmeans")
library("e1071")
library("lmtest")

# LOAD DATA ####
#Download manatees.csv -> click the Environment Tab to the right ->Import Dataset ->From Text(Base)--, manatees.csv

# QUESTION ############
# The question you are trying to answer with this analysis is: 
# Do the number of powerboats registered in Florida impact the number of manatees 
# killed there by powerboats each year?

# DATA WRANGLING ####
# Luckily, there is no additional data wrangling you will need to do with 
# this dataset to complete a linear regression.

# TEST ASSUMPTIONS ####
# You will now begin the onerous process of testing all the assumptions for 
# linear regression. Although it can be a lot of work, it is an important part of 
# regression because it will ensure that your results are as accurate as they can be.

# TESTING FOR LINEARITY ####
# Before conducting a regression analysis, it is important to first create a 
# scatterplot and visually examine the data. You can only use linear regression 
# when the two variables show a "linear" shape. If the data look like a random 
# scattering of points, curved, or any other strange shape, there is no linear 
# relationship in the data, and so it's not appropriate to run linear regression. 
# Start by looking at the scatterplot, to determine whether you have a linear 
# relationship between your two variables.
# Here's some example code to get a scatterplot:
scatter.smooth(x=manatees$PowerBoats, y=manatees$ManateeDeaths, main="Manatee Deaths by Power Boats")

# Where scatter.smooth tells R you want a scatterplot with a line, you specify 
# your x (in this case, PowerBoats) and your y (ManateeDeaths), and then can 
# put a title on it with main= if you'd like. If you're just screening data 
# quickly and no one else will see what you've created, by all means, skip the title step!
# As you can see, there is a linear relationship between the number of power 
# boats and the number of manatee deaths. 

#This means you have passed the assumption of linearity!

# TESTING FOR HOMOSCEDASTICITY ####
# Now you need to check for homoscedasticity

# CREATE THE LINEAR MODEL ####
# In order to do this, you first need to create the basic regression model, 
# because you will be able to run a whole bunch of tests once you have it, 
# including the test for homoscedasticity. Here is the code to create a linear model:
lmMod <- lm(ManateeDeaths~PowerBoats, data=manatees)

# This creates a model named lmMod (you could name it whatever you like, 
# but choose something you can easily recognize in the future and/or will make 
# sense to your coworkers), using the lm function, which stands for...you 
# guessed it...linear model! Put your dependent variable first, in this case, 
# ManateeDeaths, and then a tilde (~) to mean "by" and then specify your 
# independent variable. Lastly, specify the dataset with the data= command.

# TEST FOR HOMOSCEDASTICITY ####
# So you now have a model created, but you don't actually want to test a 
# hypothesis yet. You want to see if this model is robust enough to use for 
# analysis, which means it needs to meet all of our assumptions. You can create 
# some graphs that will allow you to test for homoscedasticity using this code:
par(mfrow=c(2,2))
plot(lmMod)

# It shows four plots, which all examine different information about residuals. 
# The ones you really want to pay attention to are on the left. The top left 
# graph shows the fitted values against the residuals, while the bottom left 
# shows the fitted values against the standardized residuals. Both of these 
# graphs should show random points with a flat red line, straight across, 
# if they are homoscedastic and thus meeting the assumptions that allow you to 
# complete linear regression. However, you can see a suspicious upward trend 
# in your residuals, specifically in the bottom of the two left plots. 
# This raises a red flag. You can declare this to be heteroscedastic 
# (the opposite of homoscedastic).

# If you're on the fence, or you're not graphically inclined, you can also test 
# for homoscedasticity with the Breush-Pagan test or the Non-Constant Variance 
# (NCV) test. Here's the code for the Breush-Pagan test:
lmtest::bptest(lmMod)

# results BP = 7.8867, df = 1, p-value = 0.00498
# You'll notice we have a p value of .004. Since this is less than .05, it means 
# it is significant, and having a significant Breush-Pagan test means that you 
# unfortunately have heteroscedasticity.

# Similarly, here's the code for the NCV test:
car::ncvTest(lmMod)

# Which yields these results:
# Non-constant Variance Score Test 
# Variance formula: ~ fitted.values 
# Chisquare = 9.037421, Df = 1, p = 0.0026451

# CORRECTING FOR HOMOSCEDASTICITY VIOLATIONS ####
# So, you violated an assumption for R, which means that whatever regression model 
# you build has a much higher likelihood of being biased. Lucky for you, most 
# of the time, you can recover from a violation of homoscedasticity.

# The first thing to try is to transform your dependent variable. 
# You'll use a Box-Cox transformation, to try and make your data more normal. 
# And no, you haven't just stepped into a Dr. Seuss book. You can run the 
# following code from the caret library:
distBCMod1 <- caret::BoxCoxTrans(manatees$ManateeDeaths)
print(distBCMod1)

# The code above will perform the Box-Cox transformation and if you print it, 
# you get some statistics about your new data, But this by itself is not 
# incredibly helpful, though it can be nice to summary statistics on your 
# transformed dependent variable. In order to re-test your transformed variable, 
# you need to bind it to the current dataset, using the function cbind():
manatees <- cbind(manatees, dist_newM=predict(distBCMod1, manatees$ManateeDeaths))

# You use the cbind() function to tack on the new variable, which has been named
# dist_newM, which is filled with the predicted data from the Box-Cox 
# transformation you did above (distBCMod1).

# Then it's just a simple matter of creating a new linear model using your 
# transformed dependent variable, and testing it once more with either the 
# Breush-Pagan test or the NCV test, like so:
lmMod_bc2 <- lm(dist_newM~PowerBoats, data=manatees)
lmtest::bptest(lmMod_bc2)

# Here is the output of the Breush-Pagan test:
# data:  lmMod_bc2
# BP = 5.6078, df = 1, p-value = 0.01788

# You'll notice that the results are still significant. So you are STILL 
# violating the assumption of homoscedasticity, which is a bummer. 
# But cheer up, friend - don't lose all hope yet. If even after Box-Cox 
# transformation your data still does not meet the assumption of homoscedasticity, 
# you can use a different method for calculating the linear regression model. 
# Up until now, you have been using ordinary least squares (OLS) regression, 
# which is by far the most popular, because it is the simplest. 
# OLS fits your regression line by looking at the minimum sum of squares of the 
# residual. However, there are a myriad of other methods from which to choose.

#One of those methods is generalized least squares. If you find yourself in need, 
# check out this R Pubs on heteroscedasticity and how to correct for it. 
# Changing your regression method, however, is relatively advanced, 
# and just for the purposes of learning, you'll continue on with the regression 
# even though you have violated the assumption of homoscedasticity.
# link to pub https://rpubs.com/cyobero/187387

# TESTING FOR HOMOGENEITY OF VARIANCE ####
# Above, you were able to generate plots for testing homoscedasticity by 
# looking at your residuals. These plots also provide useful information about 
# homogeneity of variance, or how evenly your data is distributed. 
# All you need to do is to see whether your data forms a nice box, or whether 
# it is cone shaped at either end. In this case, the residual plots you 
# generated above (repeated here for your convenience) show no cone, 
# so you have passed the assumption of homogeneity of variance.

# GVLMA LIBRARY FOR ASSUMPTIONS ####
# To add additional tools to your arsenal, there is yet another way to test 
# assumptions: the gvlma library. This will automatically run several assumption 
# tests on your data and tell you in plain language whether you have met that 
# assumption. However, beware! The gvlma function does not test all assumptions 
# necessary for regression and may not always be accurate, so make sure to 
# investigate each thoroughly regardless of the gvlma findings. When you are 
# pressed for time, are just scoping out your data, or are analyzing extremely 
# low-stakes data, however, you may find ````gvlma``` a lifesaver. Here's the code:
gvlma(lmMod_bc2)

# Go over each piece of the output point by point:
  
#Global Stat: This indicates whether the relationship between your x and y data 
# is linear.

#If you recall from the scatterplot above, the relationship is linear, so this 
# is a great example of why you do not want to fully trust GVLMA.

#Skewness: This is a measure of whether your data is normally distributed horizontally.

#Kurtosis: This is an indicator of whether your data is normally distributed vertically.

#Link Function: This tests whether your variable is continuous. If this has been
# violated, then data is categorical and analyses such as logistic regression 
# should be used instead.

#Your model has not satisfied this assumption according to GVLMA, but guess what?
# Both the number of Power Boats and the number of Manatee Deaths are continuous, 
# not categorical. Make sure to carefully investigate GVLMA results.

#Heteroscedasticity: This is an indicator of whether your residuals are constant. 
# If you fail this, you fail the assumption of homoscedasticity discussed extensively above.

# SCREENING FOR OUTLIERS ####
# Next, you will screen for outliers. You will need to test for all three types 
# of outliers: distance, leverage, and influential points.

# TESTING FOR OUTLIERS IN X SPACE ####
# You will start by screening for outliers in x space. You can do this by 
# looking at Cook's Distance values. To do this, you'll use the predictmeans 
# library. Just run your regression model through the function CookD. It will 
# generate a plot that highlights anything that is an outlier in x space.
CookD(lmMod, group=NULL, plot=TRUE, idn=3, newwd=TRUE)

# You'll note that the numbers on the plot are the row numbers of data that are 
# outliers in x space. So cases numbered 24, 26, and 29 are all outliers in x space.

# You can also look at leverage values. Anything that has a leverage value of 
# between .2 and .5 is a moderate problem, and anything over .5 is a major problem.

# To test for leverage, you will use the ```hat`` function and then plot it:
lev = hat(model.matrix(lmMod))
plot(lev)

# You can probably guess that you don't have anything over .2 by looking at this chart, 
# but it's good to know for sure. You can check with the code below, which will 
# provide you with a list of data points with leverage over .2.
manatees[lev>.2,]

# In this case, this is the only output you get out, and the lack of numbers 
# tells out that you have no outliers with a leverage over .2, 
# like you suspected in your chart.

# TESTING FOR OUTLIERS IN Y SPACE ####
# Next you want to test for outliers in y space. This is typically done using 
# something called the studentized deleted residual, or sometimes just 
# shortened to the studentized residual. This is similar to your regular 
# residual, or error term, which you have already learned, but instead of 
# calculating standard error with all of the residuals, you calculate it 
# based on n - 1. This means that you have deleted one residual, which is 
# where the name comes from.

# There is a simple line of code coming from the car library for the outlierTest 
# function that will provide you with information about the studentized deleted residual:
car::outlierTest(lmMod)

# This particular code tests for the very furthest outlier. If the Bonferroni 
# p value is significant (i.e. less than .05), then it is likely that you have 
# at least one outlier. You can also look at the column for rstudent, which is 
# the raw studentized deleted residual. If this value is over 2.5 or 3ish, 
# you have a problem with outliers in the y space. Here your value is 2.6, 
# so it could be considered an outlier, but since your Bonferroni p value is not 
# significant, you'll leave it be. You have no outliers in y space.

# TESTING FOR OUTLIERS IN X AND Y SPACE ####
# To test for influential values, or outliers in both x and y space, 
# there are two metrics to look at: DFFITS and DFBETAS.

# They are readily available with the function influence.measures for your model. Check it out!
summary(influence.measures(lmMod))

# You have a wide variety of outlier indicators here along the top, and the row 
# numbers of any values that may be outliers are shown on the far left. 
# The column named dfb.1_ is for DFBETAS, and the one named dffit is for DFFITS. 
# If a DFFITS or DFBETAS value is greater 1, you most likely have a problem with 
# outliers that are influential. Luckily in this case, there are no values greater 
# than 1 for these three points, so you have no influential outliers in your data. 




