# wozu-git-example-2021
Practicing these skills again
Hello World... Once again! Muahhahaha!