###### MANOVA Preparation in R

####Load Libraries
library("mvnormtest")
library("car")

####Load in Data
heartAttacks <- read.csv("C:/Users/lzela/Downloads/heartAttacks.csv")
View(heartAttacks)

####Question Set Up
#It is well-known that men are more likely to have heart attacks than women. How does gender (sex) influence some of the heart attack predictors like resting blood pressure (trestbps) and cholesterol (chol)?
#the independent variable will be the gender(sex). This is a categorical variable.
#The two dependent variables will be the resting blood pressure(trestbps) and cholesterol(chol). These variables are both continuous.

####Data Wrangling
#Although no data wrangling is actually required for the MANOVA itself, some wrangling is required to test for assumptions. In order to test for multivariate normality, you will need to create a dataset containing only your two dependent variables that is in a matrix format, and you will need to ensure that they are numeric. Unfortunately, the test for normality can only handle 5,000 records, so you will also need to limit your data to 5,000 rows as well.

#Ensure Variables are Numeric
str(heartAttacks$trestbps)
str(heartAttacks$chol)

#Change from integer to numeric
heartAttacks$trestbps <- as.numeric(heartAttacks$trestbps)
heartAttacks$chol <- as.numeric(heartAttacks$chol)

#Subsetting - only keep the two dependent variables, trestbps and chol
keeps <- c("trestbps", "chol")
heartAttacks1 <- heartAttacks[keeps]

#limit the number of rows (remember: maximum is 5000)
heartAttacks2 <- heartAttacks1[1:5000,]

#Format as a Matrix
heartAttacks3 <- as.matrix(heartAttacks2)

#####Test Assumptions

####Sample Size
#These are fulfilled with a dataset of 303!

####Multivariate Normality
#We'll use heartAttacks3 in the Wilks-Shapiro test. using mshapiro.test() from mvnormtest library.
mshapiro.test(t(heartAttacks3))
#Violated the assumption of multivariate normality if the p value is significant at p < .05, so unfortunately, these data do not meet the assumption for MANOVAs. However, for learning purposes, I will continue.

####Homogeneity of Variance for trestbps
#Use levene's test from car to test for above on both DVs.
leveneTest(trestbps ~ sex, data=heartAttacks)
####Homogeneity of Variance for chol
#Use levene's test from car to test for above on both DVs.
leveneTest(chol ~ sex, data=heartAttacks)
#RESULTS FROM BOTH: Unfortunately, neither variable met the assumption of homogeneity of variance, since they were both significant at p < .05. You have violated the assumption of homogeneity of variance, but you will proceed for now for learning purposes.

####Absence of Multicollinearity
#Typically, multicollinearity can be assessed simply by running correlations of your dependent variables with each other. A general rule of thumb is that anything above approximately .7 for correlation (i.e. a strong correlation) indicates the presence of multicollinearity. Check out the correlation between trestbps and chol with a simple cor.test() function:
cor.test(heartAttacks$trestbps, heartAttacks$chol, method="pearson", use="complete.obs")
#No presence of multicollinearity since less than .7

####The Analysis
#You will use the function manova to run a MANOVA. Go figure!
MANOVA <- manova(cbind(trestbps, chol) ~ sex, data = heartAttacks)
summary(MANOVA)
#It was significant - there is a significant difference in how sex influences some of the heart attack predictors like resting BP and cholesterol.

####Post Hocs
#But which dependent variable you ask? Well, that's where the post-hocs come in.

####ANOVAs as Post Hocs
summary.aov(MANOVA, test = "wilks")
#There was a ginormous significant difference in how sex influences resting blood pressure and choleterol.