#Part I: ANOVAs in R

#import data
avocados <- read.csv("C:/Users/lzela/Downloads/avocados.csv")

#Load Libraries
library("dplyr")
library("rcompanion")
library("car")
library("ggplot2")
library("IDPmisc")
library("tidyr")

#Question: Does the average price of avocados differ between Albany, Houston, and Seattle?

#Test Assumptions

# Normality
plotNormalHistogram(avocados$AveragePrice)

#Square root it
avocados$AveragePriceSQRT <- sqrt(avocados$AveragePrice)
plotNormalHistogram(avocados$AveragePrice)

#Didn't see a difference, try log just in case
avocados$AveragePriceLOG <- log(avocados$AveragePrice)
plotNormalHistogram(avocados$AveragePriceLOG)
#This is the one that looks the best!

# Homogeneity of Variance
bartlett.test(AveragePriceLOG ~ region, data=avocados)
# Does not meet the assumption for homogeneity of variance.

#Fligner's Test
fligner.test(AveragePriceLOG ~ region, data=avocados)
# Does not meet the assumption for homogeneity of variance.

# Do the Test, with unequal variance
ANOVA1 <- lm(AveragePriceLOG ~ region, data=avocados)
Anova(ANOVA1, Type="II", white.adjust=TRUE)

# Do the Post Hocs with unequal variance
pairwise.t.test(avocados$AveragePrice, avocados$region, p.adjust="bonferroni", pool.sd = FALSE)
#Non-significant - The average price of avocados aren't much different between Albany, Houston, and Seattle.
