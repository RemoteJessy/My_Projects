#Load Libraries
library("rcompanion")
library("car")
library("effects")
library("multcomp")

#Load in Data
cellPhone <- read.csv("C:/Users/lzela/Downloads/cellPhone.csv")
View(cellPhone)

#This is to see if the Night.minutes differ by whether they have an international phone plan, holding voice mail plans constant.  

## Testing Assumptions

### Normality - Need to examine both GPA and TOEFL score

library("rcompanion")
library("car")
library("effects")
library("multcomp")

plotNormalHistogram(cellPhone$Night.Mins)

# Normally distributed.

### Homogeneity of Variance

leveneTest(Night.Mins~International.Plan, data=cellPhone)

# Not significant, assumption is met!

### Homogeneity of Regression Slopes

Homogeneity_RegrSlp = lm(Night.Mins~vMail.Plan, data=cellPhone)
anova(Homogeneity_RegrSlp)

# Assumption met.

### Sample size met - 20/IV or CV. I have 2, so need at least 40 and there are over 4,000+ cases.

## Analysis

ANCOVA = lm(Night.Mins~vMail.Plan + International.Plan*vMail.Plan, data=cellPhone)
anova(ANCOVA)

# Whether a client has an international plan or not does not influence the number of night minutes he or she uses, even holding whether they have a voice mail plan constant.